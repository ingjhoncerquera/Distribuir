<?php
declare(strict_types=1);

/**
 * SITA - Seguimiento físico de Promoción y Prevención.
 * Archivo: controllers/SeguimientoFisicoController.php
 * Requiere el permiso bienestar.seguimiento_fisico.ver para consultar
 * y bienestar.seguimiento_fisico.registrar para guardar mediciones.
 */
class SeguimientoFisicoController extends Controller
{
    private SeguimientoFisicoModel $model;

    public function __construct()
    {
        $this->model = new SeguimientoFisicoModel();
    }

    public function index(): void
    {
        Auth::requirePermission('bienestar.seguimiento_fisico.ver');

        $usuario = Auth::user() ?? [];
        $idUsuario = (int) ($usuario['id'] ?? 0);
        $roles = Auth::roles();
        $esAdministrador = $this->tieneRol($roles, ['Administrador', 'Superadministrador', 'Coordinador']);
        $buscar = trim((string) $this->get('buscar', ''));
        $idFicha = max(0, (int) $this->get('id_ficha', 0));
        $idAprendiz = max(0, (int) $this->get('id_aprendiz', 0));

        $fichas = $this->model->listarFichasDisponibles($idUsuario, $esAdministrador);
        $fichasPermitidas = array_map(static fn(array $f): int => (int) $f['id'], $fichas);

        if ($idFicha > 0 && !in_array($idFicha, $fichasPermitidas, true)) {
            http_response_code(403);
            exit('No tiene autorización para consultar esta ficha.');
        }

        $aprendices = $idFicha > 0
            ? $this->model->listarAprendices($idFicha, $buscar)
            : [];

        $aprendizSeleccionado = null;
        $historial = [];
        $ultimo = null;
        $proximaFecha = null;

        if ($idAprendiz > 0 && $idFicha > 0) {
            $aprendizSeleccionado = $this->model->obtenerAprendizDeFicha($idAprendiz, $idFicha);
            if (!$aprendizSeleccionado) {
                http_response_code(404);
                exit('El aprendiz no pertenece a la ficha seleccionada o no está disponible.');
            }
            $historial = $this->model->historial($idAprendiz, $idFicha);
            $ultimo = $historial[0] ?? null;
            $proximaFecha = $ultimo['proxima_fecha'] ?? null;
        }

        $mensaje = (string) ($_SESSION['flash_seguimiento_fisico'] ?? '');
        unset($_SESSION['flash_seguimiento_fisico']);
        $error = (string) ($_SESSION['error_seguimiento_fisico'] ?? '');
        unset($_SESSION['error_seguimiento_fisico']);

        $this->view('bienestar/seguimiento_fisico/index', [
            'tituloPagina' => 'Seguimiento Físico PyP',
            'fichas' => $fichas,
            'idFicha' => $idFicha,
            'buscar' => $buscar,
            'aprendices' => $aprendices,
            'idAprendiz' => $idAprendiz,
            'aprendizSeleccionado' => $aprendizSeleccionado,
            'historial' => $historial,
            'ultimo' => $ultimo,
            'proximaFecha' => $proximaFecha,
            'puedeRegistrar' => Auth::can('bienestar.seguimiento_fisico.registrar'),
            'mensaje' => $mensaje,
            'error' => $error,
        ]);
    }

    public function guardar(): void
    {
        Auth::requirePermission('bienestar.seguimiento_fisico.registrar');
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            $this->redirect('/bienestar/seguimiento-fisico');
            return;
        }

        $this->exigirCsrf();
        $usuario = Auth::user() ?? [];
        $idUsuario = (int) ($usuario['id'] ?? 0);
        $roles = Auth::roles();
        $esAdministrador = $this->tieneRol($roles, ['Administrador', 'Superadministrador', 'Coordinador']);

        $idFicha = (int) ($_POST['id_ficha'] ?? 0);
        $idAprendiz = (int) ($_POST['id_aprendiz'] ?? 0);

        try {
            if ($idUsuario <= 0 || $idFicha <= 0 || $idAprendiz <= 0) {
                throw new InvalidArgumentException('Seleccione una ficha y un aprendiz válidos.');
            }
            if (!$this->model->usuarioPuedeGestionarFicha($idUsuario, $idFicha, $esAdministrador)) {
                throw new RuntimeException('No tiene autorización para registrar seguimientos en esta ficha.');
            }
            if (!$this->model->obtenerAprendizDeFicha($idAprendiz, $idFicha)) {
                throw new RuntimeException('El aprendiz seleccionado no pertenece a la ficha indicada.');
            }

            $fechaToma = trim((string) ($_POST['fecha_toma'] ?? ''));
            $peso = $this->numeroOpcional($_POST['peso'] ?? null, 'peso');
            $talla = $this->numeroOpcional($_POST['talla'] ?? null, 'talla');
            $sistolica = $this->enteroOpcional($_POST['presion_sistolica'] ?? null, 'presión sistólica');
            $diastolica = $this->enteroOpcional($_POST['presion_diastolica'] ?? null, 'presión diastólica');
            $fc = $this->enteroOpcional($_POST['frecuencia_cardiaca'] ?? null, 'frecuencia cardíaca');
            $fr = $this->enteroOpcional($_POST['frecuencia_respiratoria'] ?? null, 'frecuencia respiratoria');
            $temperatura = $this->numeroOpcional($_POST['temperatura'] ?? null, 'temperatura');
            $saturacion = $this->numeroOpcional($_POST['saturacion_oxigeno'] ?? null, 'saturación de oxígeno');
            $observaciones = trim((string) ($_POST['observaciones'] ?? ''));

            $fecha = DateTime::createFromFormat('Y-m-d\TH:i', $fechaToma)
                ?: DateTime::createFromFormat('Y-m-d H:i:s', $fechaToma)
                ?: DateTime::createFromFormat('Y-m-d', $fechaToma);
            if (!$fecha || $fecha->format('Y-m-d') > date('Y-m-d')) {
                throw new InvalidArgumentException('La fecha de toma no es válida o está en el futuro.');
            }
            if ($peso === null || $peso < 1 || $peso > 500) {
                throw new InvalidArgumentException('El peso es obligatorio y debe estar entre 1 y 500 kg.');
            }
            if ($talla === null || $talla < 0.3 || $talla > 2.5) {
                throw new InvalidArgumentException('La talla es obligatoria y debe registrarse en metros (por ejemplo, 1.72).');
            }
            if (($sistolica === null) !== ($diastolica === null)) {
                throw new InvalidArgumentException('Registre ambos valores de presión arterial o deje ambos vacíos.');
            }
            if ($sistolica !== null && ($sistolica < 40 || $sistolica > 300 || $diastolica < 20 || $diastolica > 200)) {
                throw new InvalidArgumentException('Revise los valores de presión arterial ingresados.');
            }
            if ($fc !== null && ($fc < 1 || $fc > 300)) throw new InvalidArgumentException('Frecuencia cardíaca fuera del rango permitido para captura.');
            if ($fr !== null && ($fr < 1 || $fr > 100)) throw new InvalidArgumentException('Frecuencia respiratoria fuera del rango permitido para captura.');
            if ($temperatura !== null && ($temperatura < 25 || $temperatura > 45)) throw new InvalidArgumentException('Revise la temperatura ingresada.');
            if ($saturacion !== null && ($saturacion < 0 || $saturacion > 100)) throw new InvalidArgumentException('La saturación debe estar entre 0 y 100 %.');
            if (mb_strlen($observaciones) > 3000) throw new InvalidArgumentException('Las observaciones no pueden superar 3000 caracteres.');

            $this->model->crear([
                'id_aprendiz' => $idAprendiz,
                'id_ficha' => $idFicha,
                'id_usuario' => $idUsuario,
                'fecha_toma' => $fecha->format('Y-m-d H:i:s'),
                'peso' => $peso,
                'talla' => $talla,
                'imc' => round($peso / ($talla * $talla), 2),
                'presion_sistolica' => $sistolica,
                'presion_diastolica' => $diastolica,
                'frecuencia_cardiaca' => $fc,
                'frecuencia_respiratoria' => $fr,
                'temperatura' => $temperatura,
                'saturacion_oxigeno' => $saturacion,
                'observaciones' => $observaciones !== '' ? $observaciones : null,
                'proxima_fecha' => (clone $fecha)->modify('+3 months')->format('Y-m-d'),
            ]);

            $_SESSION['flash_seguimiento_fisico'] = 'Seguimiento guardado correctamente. El historial anterior se conservó.';
        } catch (Throwable $e) {
            $_SESSION['error_seguimiento_fisico'] = $e instanceof InvalidArgumentException || $e instanceof RuntimeException
                ? $e->getMessage()
                : 'No fue posible guardar el seguimiento. Verifique la base de datos o contacte al administrador.';
        }

        $this->redirect('/bienestar/seguimiento-fisico?id_ficha=' . $idFicha . '&id_aprendiz=' . $idAprendiz);
    }

    /** Validación CSRF siguiendo el esquema de sesión usado por SITA. */
    private function exigirCsrf(): void
    {
        $tokenFormulario = (string) ($_POST['csrf_token'] ?? '');
        $tokenSesion = (string) ($_SESSION['csrf_token'] ?? '');
        if ($tokenFormulario === '' || $tokenSesion === '' || !hash_equals($tokenSesion, $tokenFormulario)) {
            http_response_code(419);
            exit('La sesión del formulario expiró o el token de seguridad no es válido. Regrese al formulario e inténtelo nuevamente.');
        }
    }

    private function numeroOpcional(mixed $valor, string $campo): ?float
    {
        if ($valor === null || trim((string) $valor) === '') return null;
        $normalizado = str_replace(',', '.', trim((string) $valor));
        if (!is_numeric($normalizado)) throw new InvalidArgumentException('El campo ' . $campo . ' debe ser numérico.');
        return (float) $normalizado;
    }

    private function enteroOpcional(mixed $valor, string $campo): ?int
    {
        $numero = $this->numeroOpcional($valor, $campo);
        if ($numero === null) return null;
        if (floor($numero) !== $numero) throw new InvalidArgumentException('El campo ' . $campo . ' debe ser un número entero.');
        return (int) $numero;
    }

    private function tieneRol(array $roles, array $permitidos): bool
    {
        $normalizar = static function (string $valor): string {
            $valor = mb_strtolower(trim($valor));
            return str_replace(['í', 'á', 'é'], ['i', 'a', 'e'], $valor);
        };
        foreach ($roles as $rol) {
            $nombre = is_array($rol) ? (string) ($rol['nombre'] ?? $rol['rol'] ?? '') : (string) $rol;
            foreach ($permitidos as $permitido) {
                if ($normalizar($nombre) === $normalizar($permitido)) return true;
            }
        }
        return false;
    }
}
