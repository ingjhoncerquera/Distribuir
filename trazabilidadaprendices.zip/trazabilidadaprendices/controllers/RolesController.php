<?php

declare(strict_types=1);

class RolesController extends Controller
{
    private RolModel $rolModel;

    public function __construct()
    {
        $this->rolModel = new RolModel();
    }

    /**
     * Lista los roles activos del sistema.
     */
    public function index(): void
    {
        Auth::requirePermission('roles.ver');

        $roles = $this->rolModel->listarActivos();

        $this->view(
            'roles/index',
            [
                'tituloPagina' => 'Roles',
                'roles' => $roles,
            ]
        );
    }

    /**
     * Muestra el formulario para crear un nuevo rol.
     */
    public function crear(): void
    {
        Auth::requirePermission('roles.editar');

        $this->view(
            'roles/crear',
            [
                'tituloPagina' => 'Crear rol',
            ]
        );
    }

    /**
     * Guarda un nuevo rol.
     */
    public function guardar(): void
    {
        Auth::requirePermission('roles.editar');

        if (!$this->isPost()) {
            redirect('/roles');
        }

        exigirCsrf();

        $nombre = trim(
            (string) $this->post(
                'nombre',
                ''
            )
        );

        $descripcion = trim(
            (string) $this->post(
                'descripcion',
                ''
            )
        );

        $estado = trim(
            (string) $this->post(
                'estado',
                'activo'
            )
        );

        if ($nombre === '') {
            flash(
                'error',
                'El nombre del rol es obligatorio.'
            );

            redirect('/roles/crear');
        }

        if (mb_strlen($nombre) > 50) {
            flash(
                'error',
                'El nombre del rol no puede superar los 50 caracteres.'
            );

            redirect('/roles/crear');
        }

        if ($descripcion !== '' && mb_strlen($descripcion) > 255) {
            flash(
                'error',
                'La descripción no puede superar los 255 caracteres.'
            );

            redirect('/roles/crear');
        }

        if (!in_array(
            $estado,
            ['activo', 'inactivo'],
            true
        )) {
            flash(
                'error',
                'El estado seleccionado no es válido.'
            );

            redirect('/roles/crear');
        }

        if ($this->rolModel->existeNombre($nombre)) {
            flash(
                'error',
                'Ya existe un rol con ese nombre.'
            );

            redirect('/roles/crear');
        }

        $idRol = $this->rolModel->crear(
            $nombre,
            $descripcion !== '' ? $descripcion : null,
            $estado
        );

        if ($idRol === null) {
            flash(
                'error',
                'No fue posible crear el rol.'
            );

            redirect('/roles/crear');
        }

        flash(
            'success',
            'El rol fue creado correctamente. Ahora puede asignarle permisos.'
        );

        redirect(
            '/roles/permisos?id='
            . $idRol
        );
    }

    /**
     * Muestra los permisos disponibles y los permisos
     * actualmente asignados al rol seleccionado.
     */
    public function permisos(): void
    {
        Auth::requirePermission('roles.ver');

        $idRol = (int) $this->get('id', 0);

        if ($idRol <= 0) {
            flash(
                'error',
                'El rol seleccionado no es válido.'
            );

            redirect('/roles');
        }

        $rol = $this->rolModel->obtener($idRol);

        if (!$rol) {
            flash(
                'error',
                'El rol seleccionado no existe.'
            );

            redirect('/roles');
        }

        $permisos = $this->rolModel->listarPermisos();

        $idsPermisosAsignados =
            $this->rolModel->obtenerIdsPermisos(
                $idRol
            );

        $this->view(
            'roles/permisos',
            [
                'tituloPagina' => 'Permisos del rol',
                'rol' => $rol,
                'permisos' => $permisos,
                'idsPermisosAsignados' => $idsPermisosAsignados,
            ]
        );
    }

    /**
     * Guarda los permisos seleccionados para un rol.
     */
    public function guardarPermisos(): void
    {
        Auth::requirePermission('roles.editar');

        if (!$this->isPost()) {
            redirect('/roles');
        }

        exigirCsrf();

        $idRol = (int) $this->post(
            'id_rol',
            0
        );

        if ($idRol <= 0) {
            flash(
                'error',
                'El rol seleccionado no es válido.'
            );

            redirect('/roles');
        }

        $rol = $this->rolModel->obtener($idRol);

        if (!$rol) {
            flash(
                'error',
                'El rol seleccionado no existe.'
            );

            redirect('/roles');
        }

        $idsPermisos = $this->post(
            'permisos',
            []
        );

        if (!is_array($idsPermisos)) {
            $idsPermisos = [];
        }

        $guardado = $this->rolModel->guardarPermisos(
            $idRol,
            $idsPermisos
        );

        if (!$guardado) {
            flash(
                'error',
                'No fue posible guardar los permisos del rol.'
            );

            redirect(
                '/roles/permisos?id='
                . $idRol
            );
        }

        flash(
            'success',
            'Los permisos del rol fueron actualizados correctamente.'
        );

        redirect(
            '/roles/permisos?id='
            . $idRol
        );
    }
}