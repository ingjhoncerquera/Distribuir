-- SITA - LIMPIEZA DE DATOS DE PRUEBA PARA PRODUCCION
-- Base esperada: trazabilidad_aprendices
-- Objetivo:
--   * Dejar sin fichas, programas, competencias, RAP ni aprendices.
--   * Eliminar seguimientos/formularios asociados a aprendices y fichas.
--   * Conservar usuarios, contrasenas, roles, permisos y asignaciones de roles.
--   * Conservar profesionales y sus personas, catálogos EPS/tipos de población,
--     jornadas/etapas, auditoría y todo el módulo administrativo de materiales.
--   * No elimina ni modifica la estructura de ninguna tabla.
--
-- PRECAUCION: haga primero una copia de seguridad completa de la base de datos.
-- Revise que seleccionó la base de datos correcta antes de ejecutar.
-- Ejecutar una sola vez desde phpMyAdmin, pestaña SQL.

USE `trazabilidad_aprendices`;

SET @OLD_FOREIGN_KEY_CHECKS = @@FOREIGN_KEY_CHECKS;
SET FOREIGN_KEY_CHECKS = 0;

START TRANSACTION;

-- Guardar las personas que estaban asociadas a aprendices para poder borrar
-- únicamente las que no pertenecen también a usuarios o profesionales.
CREATE TEMPORARY TABLE `tmp_sita_personas_aprendices` (
    `id_persona` INT(10) UNSIGNED NOT NULL PRIMARY KEY
) ENGINE=MEMORY;

INSERT IGNORE INTO `tmp_sita_personas_aprendices` (`id_persona`)
SELECT DISTINCT `id_persona`
FROM `aprendices`
WHERE `id_persona` IS NOT NULL;

-- Eliminar datos operativos de acompañamiento, salud, bienestar y caracterización.
DELETE FROM `actualizaciones_caracterizacion`;
DELETE FROM `alertas_acompanamiento`;
DELETE FROM `aprendiz_poblacion`;
DELETE FROM `compromisos`;
DELETE FROM `cuestionarios_bienestar`;
DELETE FROM `enlaces_actualizacion_ficha`;
DELETE FROM `etapas_aprendiz`;
DELETE FROM `recomendaciones_nutricionales`;
DELETE FROM `remisiones`;
DELETE FROM `resultados_aprendiz`;
DELETE FROM `seguimientos_fisicos`;
DELETE FROM `seguimientos_salud_mental`;
DELETE FROM `seguimientos_salud_sexual`;
DELETE FROM `signos_vitales`;
DELETE FROM `solicitudes_atencion`;
DELETE FROM `valoraciones_nutricionales`;
DELETE FROM `valoraciones_salud_fisica`;

-- Eliminar asignaciones académicas y matrículas de prueba.
DELETE FROM `asignaciones_ficha`;
DELETE FROM `matriculas`;

-- Eliminar aprendices de prueba y sus registros personales exclusivos.
DELETE FROM `aprendices`;

DELETE p
FROM `personas` AS p
INNER JOIN `tmp_sita_personas_aprendices` AS tmp
    ON tmp.`id_persona` = p.`id`
WHERE NOT EXISTS (
    SELECT 1 FROM `usuarios` AS u WHERE u.`id_persona` = p.`id`
)
AND NOT EXISTS (
    SELECT 1 FROM `profesionales` AS pr WHERE pr.`id_persona` = p.`id`
);

-- Dejar vacías las tablas académicas maestras solicitadas.
DELETE FROM `rap`;
DELETE FROM `competencias`;
DELETE FROM `fichas`;
DELETE FROM `programas`;

COMMIT;

DROP TEMPORARY TABLE IF EXISTS `tmp_sita_personas_aprendices`;

-- Reiniciar consecutivos de las tablas vaciadas, para comenzar desde cero.
ALTER TABLE `actualizaciones_caracterizacion` AUTO_INCREMENT = 1;
ALTER TABLE `alertas_acompanamiento` AUTO_INCREMENT = 1;
ALTER TABLE `aprendiz_poblacion` AUTO_INCREMENT = 1;
ALTER TABLE `aprendices` AUTO_INCREMENT = 1;
ALTER TABLE `asignaciones_ficha` AUTO_INCREMENT = 1;
ALTER TABLE `competencias` AUTO_INCREMENT = 1;
ALTER TABLE `compromisos` AUTO_INCREMENT = 1;
ALTER TABLE `cuestionarios_bienestar` AUTO_INCREMENT = 1;
ALTER TABLE `enlaces_actualizacion_ficha` AUTO_INCREMENT = 1;
ALTER TABLE `etapas_aprendiz` AUTO_INCREMENT = 1;
ALTER TABLE `fichas` AUTO_INCREMENT = 1;
ALTER TABLE `matriculas` AUTO_INCREMENT = 1;
ALTER TABLE `programas` AUTO_INCREMENT = 1;
ALTER TABLE `rap` AUTO_INCREMENT = 1;
ALTER TABLE `recomendaciones_nutricionales` AUTO_INCREMENT = 1;
ALTER TABLE `remisiones` AUTO_INCREMENT = 1;
ALTER TABLE `resultados_aprendiz` AUTO_INCREMENT = 1;
ALTER TABLE `seguimientos_fisicos` AUTO_INCREMENT = 1;
ALTER TABLE `seguimientos_salud_mental` AUTO_INCREMENT = 1;
ALTER TABLE `seguimientos_salud_sexual` AUTO_INCREMENT = 1;
ALTER TABLE `signos_vitales` AUTO_INCREMENT = 1;
ALTER TABLE `solicitudes_atencion` AUTO_INCREMENT = 1;
ALTER TABLE `valoraciones_nutricionales` AUTO_INCREMENT = 1;
ALTER TABLE `valoraciones_salud_fisica` AUTO_INCREMENT = 1;
ALTER TABLE `etapas_aprendiz` AUTO_INCREMENT = 1;

SET FOREIGN_KEY_CHECKS = @OLD_FOREIGN_KEY_CHECKS;

-- Verificación posterior: todas estas tablas deben devolver conteo 0.
SELECT 'aprendices' AS tabla, COUNT(*) AS registros FROM `aprendices`
UNION ALL SELECT 'fichas', COUNT(*) FROM `fichas`
UNION ALL SELECT 'programas', COUNT(*) FROM `programas`
UNION ALL SELECT 'competencias', COUNT(*) FROM `competencias`
UNION ALL SELECT 'rap', COUNT(*) FROM `rap`;

-- Las tablas usuarios, usuario_roles, roles, permisos, rol_permisos,
-- profesionales, EPS, tipos_poblacion, jornadas, etapas, auditoria y materiales_*
-- se conservan intencionalmente.
