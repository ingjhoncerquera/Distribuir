<?php

declare(strict_types=1);

class Database
{
    private string $host = 'localhost';
    private string $dbName = 'trazabilidad_aprendices';
    private string $username = 'root';
    private string $password = '';

    private ?PDO $connection = null;

    /**
     * Establece y devuelve la conexión a la base de datos.
     */
    public function conectar(): PDO
    {
        if ($this->connection instanceof PDO) {
            return $this->connection;
        }

        $dsn = "mysql:host={$this->host};dbname={$this->dbName};charset=utf8mb4";

        try {

            $this->connection = new PDO(
                $dsn,
                $this->username,
                $this->password,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );

            return $this->connection;

        } catch (PDOException $e) {

            if (
                defined('APP_DEBUG')
                && APP_DEBUG === true
            ) {
                die(
                    'Error de conexión a la base de datos: '
                    . htmlspecialchars(
                        $e->getMessage(),
                        ENT_QUOTES,
                        'UTF-8'
                    )
                );
            }

            die(
                'No fue posible conectar con la base de datos.'
            );
        }
    }
}