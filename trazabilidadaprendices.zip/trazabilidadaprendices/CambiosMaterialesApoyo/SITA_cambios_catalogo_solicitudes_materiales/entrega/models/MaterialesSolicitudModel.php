<?php

declare(strict_types=1);

class MaterialesSolicitudModel
{
    private PDO $db;

    public function __construct(?PDO $db = null)
    {
        if ($db instanceof PDO) {
            $this->db = $db;
            return;
        }

        $database = new Database();

        $this->db = $database->conectar();
    }

    /**
     * =========================================================
     * PROFESIONAL ASOCIADO AL USUARIO
     * =========================================================
     */
    public function obtenerProfesionalPorUsuario(
        int $idUsuario
    ): ?array {
        $sql = "
            SELECT
                pr.id,
                pr.id_persona,
                pr.tipo_profesional,
                pr.registro_profesional,
                pr.especialidad,
                pr.estado,

                u.id AS id_usuario,
                u.username,

                p.tipo_documento,
                p.documento,
                p.nombres,
                p.apellidos,

                CONCAT(
                    TRIM(p.nombres),
                    ' ',
                    TRIM(p.apellidos)
                ) AS nombre_completo,

                p.correo,
                p.telefono

            FROM usuarios u

            INNER JOIN personas p
                ON p.id = u.id_persona

            INNER JOIN profesionales pr
                ON pr.id_persona = p.id

            WHERE
                u.id = :id_usuario
                AND u.estado = 'activo'
                AND p.estado = 'activo'
                AND pr.estado = 'activo'

            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id_usuario' => $idUsuario,
        ]);

        $profesional = $stmt->fetch(
            PDO::FETCH_ASSOC
        );

        return $profesional ?: null;
    }

    /**
     * =========================================================
     * PROCESOS DISPONIBLES
     * =========================================================
     */
    public function listarProcesosDisponibles(): array
    {
        $sql = "
            SELECT
                id,
                anio,
                nombre,
                descripcion,
                fecha_inicio,
                fecha_cierre,
                estado,
                id_coordinador,
                created_at,
                updated_at

            FROM materiales_procesos

            WHERE estado IN (
                'abierto',
                'en_solicitud'
            )

            ORDER BY
                anio DESC,
                id DESC
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute();

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    /**
     * =========================================================
     * OBTENER PROCESO
     * =========================================================
     */
    public function obtenerProceso(
        int $idProceso
    ): ?array {
        $sql = "
            SELECT
                id,
                anio,
                nombre,
                descripcion,
                fecha_inicio,
                fecha_cierre,
                estado,
                id_coordinador,
                created_at,
                updated_at

            FROM materiales_procesos

            WHERE id = :id

            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id' => $idProceso,
        ]);

        $proceso = $stmt->fetch(
            PDO::FETCH_ASSOC
        );

        return $proceso ?: null;
    }

    /**
     * =========================================================
     * ÁREAS DISPONIBLES PARA UN PROFESIONAL
     * =========================================================
     */
    public function listarAreasPorProceso(
        int $idProceso,
        int $idProfesional
    ): array {
        $sql = "
            SELECT DISTINCT
                pa.id,
                pa.id_proceso,
                pa.nombre_area,
                pa.estado,
                pa.observaciones,
                pa.created_at,

                r.id AS id_responsable,
                r.id_profesional,
                r.fecha_designacion,
                r.fecha_fin,
                r.estado AS estado_responsable,

                prof.tipo_profesional,

                per.nombres,
                per.apellidos,

                CONCAT(
                    TRIM(per.nombres),
                    ' ',
                    TRIM(per.apellidos)
                ) AS nombre_responsable

            FROM materiales_proceso_areas pa

            INNER JOIN materiales_area_responsables r
                ON r.id_proceso_area = pa.id

            INNER JOIN profesionales prof
                ON prof.id = r.id_profesional

            INNER JOIN personas per
                ON per.id = prof.id_persona

            WHERE
                pa.id_proceso = :id_proceso
                AND pa.estado = 'activa'

                AND r.id_profesional = :id_profesional
                AND r.estado = 'activo'
                AND r.fecha_fin IS NULL

                AND prof.estado = 'activo'

            ORDER BY
                pa.nombre_area ASC,
                pa.id ASC
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id_proceso' => $idProceso,
            ':id_profesional' => $idProfesional,
        ]);

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    /**
     * =========================================================
     * OBTENER ÁREA ACTIVA
     * =========================================================
     */
    public function obtenerArea(
        int $idProcesoArea
    ): ?array {
        $sql = "
            SELECT
                pa.id,
                pa.id_proceso,
                pa.nombre_area,
                pa.estado,
                pa.observaciones,

                pr.anio,
                pr.nombre AS nombre_proceso,
                pr.estado AS estado_proceso

            FROM materiales_proceso_areas pa

            INNER JOIN materiales_procesos pr
                ON pr.id = pa.id_proceso

            WHERE
                pa.id = :id
                AND pa.estado = 'activa'

            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id' => $idProcesoArea,
        ]);

        $area = $stmt->fetch(
            PDO::FETCH_ASSOC
        );

        return $area ?: null;
    }

    /**
     * =========================================================
     * VERIFICAR RESPONSABLE DEL ÁREA
     * =========================================================
     */
    public function profesionalEsResponsableArea(
        int $idProcesoArea,
        int $idProfesional
    ): bool {
        $sql = "
            SELECT COUNT(*)

            FROM materiales_proceso_areas pa

            INNER JOIN materiales_area_responsables r
                ON r.id_proceso_area = pa.id

            INNER JOIN profesionales prof
                ON prof.id = r.id_profesional

            WHERE
                pa.id = :id_area
                AND pa.estado = 'activa'

                AND r.id_profesional = :id_profesional
                AND r.estado = 'activo'
                AND r.fecha_fin IS NULL

                AND prof.estado = 'activo'
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id_area' => $idProcesoArea,
            ':id_profesional' => $idProfesional,
        ]);

        return (int) $stmt->fetchColumn() > 0;
    }

    /**
     * =========================================================
     * MATERIALES ACTIVOS
     * =========================================================
     */
    public function listarMaterialesActivos(
        string $buscar = '',
        int $limite = 50,
        int $offset = 0
    ): array {
        $limite = max(
            1,
            min($limite, 100)
        );

        $offset = max(
            0,
            $offset
        );

        $buscar = trim($buscar);

        $where = "
            WHERE mc.estado = 'activo'
        ";

        $params = [];

        if ($buscar !== '') {

            $where .= "
                AND (
                    mc.codigo_unspsc LIKE :buscar_codigo
                    OR mc.descripcion LIKE :buscar_descripcion
                )
            ";

            $termino = '%' . $buscar . '%';

            $params[':buscar_codigo'] = $termino;
            $params[':buscar_descripcion'] = $termino;
        }

        $sql = "
            SELECT
                mc.id,
                mc.codigo_unspsc,
                mc.descripcion,
                mc.estado,
                mc.fecha_inicio_vigencia,
                mc.fecha_fin_vigencia

            FROM materiales_catalogo mc

            {$where}

            ORDER BY
                mc.descripcion ASC,
                mc.id ASC

            LIMIT {$limite}
            OFFSET {$offset}
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute($params);

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    /**
     * =========================================================
     * CONTAR MATERIALES ACTIVOS
     * =========================================================
     */
    public function contarMaterialesActivos(
        string $buscar = ''
    ): int {
        $buscar = trim($buscar);

        $where = "
            WHERE mc.estado = 'activo'
        ";

        $params = [];

        if ($buscar !== '') {

            $where .= "
                AND (
                    mc.codigo_unspsc LIKE :buscar_codigo
                    OR mc.descripcion LIKE :buscar_descripcion
                )
            ";

            $termino = '%' . $buscar . '%';

            $params[':buscar_codigo'] = $termino;
            $params[':buscar_descripcion'] = $termino;
        }

        $sql = "
            SELECT COUNT(*)

            FROM materiales_catalogo mc

            {$where}
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute($params);

        return (int) $stmt->fetchColumn();
    }

    /**
     * =========================================================
     * MATERIAL ACTIVO
     * =========================================================
     */
    public function obtenerMaterialActivo(
        int $idMaterial
    ): ?array {
        $sql = "
            SELECT
                id,
                codigo_unspsc,
                descripcion,
                estado,
                fecha_inicio_vigencia,
                fecha_fin_vigencia

            FROM materiales_catalogo

            WHERE
                id = :id
                AND estado = 'activo'

            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id' => $idMaterial,
        ]);

        $material = $stmt->fetch(
            PDO::FETCH_ASSOC
        );

        return $material ?: null;
    }

    /**
     * =========================================================
     * SOLICITUDES DEL PROFESIONAL
     * =========================================================
     */
    public function listarPorProfesional(
        int $idProfesional
    ): array {
        $sql = "
            SELECT
                s.id,
                s.id_proceso_area,
                s.id_profesional_solicitante,
                s.numero_solicitud,
                s.titulo,
                s.justificacion,
                s.estado,
                s.fecha_envio,
                s.id_usuario_revision,
                s.fecha_revision,
                s.observacion_revision,
                s.created_at,
                s.updated_at,

                pa.nombre_area,

                pr.id AS id_proceso,
                pr.anio,
                pr.nombre AS nombre_proceso,

                per.nombres,
                per.apellidos

            FROM materiales_solicitudes s

            INNER JOIN materiales_proceso_areas pa
                ON pa.id = s.id_proceso_area

            INNER JOIN materiales_procesos pr
                ON pr.id = pa.id_proceso

            INNER JOIN profesionales prof
                ON prof.id = s.id_profesional_solicitante

            INNER JOIN personas per
                ON per.id = prof.id_persona

            WHERE
                s.id_profesional_solicitante = :id_profesional

            ORDER BY
                s.created_at DESC,
                s.id DESC
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id_profesional' => $idProfesional,
        ]);

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    /**
     * =========================================================
     * OBTENER SOLICITUD
     * =========================================================
     */
    public function obtenerSolicitud(
        int $idSolicitud
    ): ?array {
        $sql = "
            SELECT
                s.id,
                s.id_proceso_area,
                s.id_profesional_solicitante,
                s.numero_solicitud,
                s.titulo,
                s.justificacion,
                s.estado,
                s.fecha_envio,
                s.id_usuario_revision,
                s.fecha_revision,
                s.observacion_revision,
                s.created_at,
                s.updated_at,

                pa.nombre_area,

                pr.id AS id_proceso,
                pr.anio,
                pr.nombre AS nombre_proceso,
                pr.estado AS estado_proceso,
                pr.id_coordinador,

                prof.id AS profesional_id,
                prof.tipo_profesional,

                per.nombres,
                per.apellidos,
                per.documento

            FROM materiales_solicitudes s

            INNER JOIN materiales_proceso_areas pa
                ON pa.id = s.id_proceso_area

            INNER JOIN materiales_procesos pr
                ON pr.id = pa.id_proceso

            INNER JOIN profesionales prof
                ON prof.id = s.id_profesional_solicitante

            INNER JOIN personas per
                ON per.id = prof.id_persona

            WHERE s.id = :id

            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id' => $idSolicitud,
        ]);

        $solicitud = $stmt->fetch(
            PDO::FETCH_ASSOC
        );

        return $solicitud ?: null;
    }

    /**
     * =========================================================
     * LISTAR SOLICITUDES PENDIENTES DE AVAL
     * =========================================================
     *
     * Si $idCoordinador es NULL:
     *     devuelve todas las solicitudes pendientes.
     *
     * Si contiene un profesional:
     *     devuelve solamente solicitudes de procesos cuyo
     *     id_coordinador corresponde a ese profesional.
     */
    public function listarPendientesAval(
        ?int $idCoordinador = null
    ): array {
        $where = "
            WHERE s.estado = 'pendiente_aval'
        ";

        $params = [];

        if ($idCoordinador !== null) {

            $where .= "
                AND pr.id_coordinador = :id_coordinador
            ";

            $params[':id_coordinador'] =
                $idCoordinador;
        }

        $sql = "
            SELECT
                s.id,
                s.id_proceso_area,
                s.id_profesional_solicitante,
                s.numero_solicitud,
                s.titulo,
                s.justificacion,
                s.estado,
                s.fecha_envio,
                s.id_usuario_revision,
                s.fecha_revision,
                s.observacion_revision,
                s.created_at,
                s.updated_at,

                pa.nombre_area,

                pr.id AS id_proceso,
                pr.anio,
                pr.nombre AS nombre_proceso,
                pr.estado AS estado_proceso,
                pr.id_coordinador,

                prof.tipo_profesional,

                per.nombres,
                per.apellidos,

                CONCAT(
                    TRIM(per.nombres),
                    ' ',
                    TRIM(per.apellidos)
                ) AS nombre_solicitante

            FROM materiales_solicitudes s

            INNER JOIN materiales_proceso_areas pa
                ON pa.id = s.id_proceso_area

            INNER JOIN materiales_procesos pr
                ON pr.id = pa.id_proceso

            INNER JOIN profesionales prof
                ON prof.id = s.id_profesional_solicitante

            INNER JOIN personas per
                ON per.id = prof.id_persona

            {$where}

            ORDER BY
                s.fecha_envio ASC,
                s.id ASC
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute($params);

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    /**
     * =========================================================
     * COORDINADOR PUEDE REVISAR SOLICITUD
     * =========================================================
     *
     * La autorización se determina por el proceso al cual
     * pertenece la solicitud.
     *
     * materiales_solicitudes
     *      ↓
     * materiales_proceso_areas
     *      ↓
     * materiales_procesos
     *      ↓
     * id_coordinador
     */
    public function coordinadorPuedeRevisarSolicitud(
        int $idSolicitud,
        int $idCoordinador
    ): bool {
        $sql = "
            SELECT COUNT(*)

            FROM materiales_solicitudes s

            INNER JOIN materiales_proceso_areas pa
                ON pa.id = s.id_proceso_area

            INNER JOIN materiales_procesos pr
                ON pr.id = pa.id_proceso

            WHERE
                s.id = :id_solicitud
                AND s.estado = 'pendiente_aval'
                AND pr.id_coordinador = :id_coordinador
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id_solicitud' =>
                $idSolicitud,

            ':id_coordinador' =>
                $idCoordinador,
        ]);

        return (int) $stmt->fetchColumn() > 0;
    }

    /**
     * =========================================================
     * DETALLES
     * =========================================================
     */
    public function listarDetalles(
        int $idSolicitud
    ): array {
        $sql = "
            SELECT
                d.id,
                d.id_solicitud,
                d.id_material,
                d.cantidad_solicitada,
                d.observaciones,
                d.descripcion_tecnica,
                d.unidad_medida,
                d.es_consumo,
                d.es_devolutivo,
                d.es_software,
                d.es_epp,

                mc.codigo_unspsc,
                mc.descripcion

            FROM materiales_solicitud_detalle d

            INNER JOIN materiales_catalogo mc
                ON mc.id = d.id_material

            WHERE
                d.id_solicitud = :id_solicitud

            ORDER BY
                d.id ASC
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id_solicitud' => $idSolicitud,
        ]);

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    /**
     * =========================================================
     * DESTINOS
     * =========================================================
     */
    public function listarDestinosPorDetalle(
        int $idDetalle
    ): array {
        $sql = "
            SELECT
                d.id,
                d.id_detalle_solicitud,
                d.tipo_destino,
                d.id_ficha,
                d.cantidad_destinada,
                d.observaciones,

                f.numero_ficha

            FROM materiales_solicitud_destinos d

            LEFT JOIN fichas f
                ON f.id = d.id_ficha

            WHERE
                d.id_detalle_solicitud = :id_detalle

            ORDER BY
                d.id ASC
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id_detalle' => $idDetalle,
        ]);

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    /**
     * =========================================================
     * NÚMERO DE SOLICITUD
     * =========================================================
     */
    public function generarNumeroSolicitud(): string
    {
        do {

            $numero = 'SOL-MAT-'
                . date('Ymd-His')
                . '-'
                . random_int(100, 999);

            $sql = "
                SELECT COUNT(*)
                FROM materiales_solicitudes
                WHERE numero_solicitud = :numero
            ";

            $stmt = $this->db->prepare($sql);

            $stmt->execute([
                ':numero' => $numero,
            ]);

            $existe =
                (int) $stmt->fetchColumn() > 0;

        } while ($existe);

        return $numero;
    }

    /**
     * =========================================================
     * CREAR BORRADOR
     * =========================================================
     */
    public function crearBorrador(
        int $idProcesoArea,
        int $idProfesional,
        string $titulo,
        ?string $justificacion
    ): int {
        $numeroSolicitud =
            $this->generarNumeroSolicitud();

        $sql = "
            INSERT INTO materiales_solicitudes (
                id_proceso_area,
                id_profesional_solicitante,
                numero_solicitud,
                titulo,
                justificacion,
                estado
            )
            VALUES (
                :id_proceso_area,
                :id_profesional,
                :numero_solicitud,
                :titulo,
                :justificacion,
                'borrador'
            )
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id_proceso_area' => $idProcesoArea,
            ':id_profesional' => $idProfesional,
            ':numero_solicitud' => $numeroSolicitud,
            ':titulo' => $titulo,
            ':justificacion' => $justificacion,
        ]);

        return (int) $this->db->lastInsertId();
    }

    /**
     * =========================================================
     * AGREGAR DETALLE
     * =========================================================
     */
    public function agregarDetalle(
        int $idSolicitud,
        int $idMaterial,
        float $cantidad,
        ?string $observaciones = null,
        string $unidadMedida = '',
        string $descripcionTecnica = '',
        int $esConsumo = 0,
        int $esDevolutivo = 0,
        int $esSoftware = 0,
        int $esEpp = 0
    ): int {
        $sql = "
            INSERT INTO materiales_solicitud_detalle (
                id_solicitud, id_material, cantidad_solicitada,
                observaciones, unidad_medida, descripcion_tecnica,
                es_consumo, es_devolutivo, es_software, es_epp
            ) VALUES (
                :id_solicitud, :id_material, :cantidad,
                :observaciones, :unidad_medida, :descripcion_tecnica,
                :es_consumo, :es_devolutivo, :es_software, :es_epp
            )
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':id_solicitud' => $idSolicitud,
            ':id_material' => $idMaterial,
            ':cantidad' => $cantidad,
            ':observaciones' => $observaciones,
            ':unidad_medida' => $unidadMedida,
            ':descripcion_tecnica' => $descripcionTecnica,
            ':es_consumo' => $esConsumo ? 1 : 0,
            ':es_devolutivo' => $esDevolutivo ? 1 : 0,
            ':es_software' => $esSoftware ? 1 : 0,
            ':es_epp' => $esEpp ? 1 : 0,
        ]);
        return (int) $this->db->lastInsertId();
    }

    /**
     * Actualiza los campos del detalle; los argumentos nulos conservan
     * los datos existentes para mantener compatibilidad con llamadas antiguas.
     */
    public function actualizarDetalle(
        int $idDetalle,
        float $cantidad,
        ?string $observaciones = null,
        ?string $unidadMedida = null,
        ?string $descripcionTecnica = null,
        ?int $esConsumo = null,
        ?int $esDevolutivo = null,
        ?int $esSoftware = null,
        ?int $esEpp = null
    ): bool {
        $sql = "
            UPDATE materiales_solicitud_detalle
            SET cantidad_solicitada = :cantidad,
                observaciones = :observaciones,
                unidad_medida = COALESCE(:unidad_medida, unidad_medida),
                descripcion_tecnica = COALESCE(:descripcion_tecnica, descripcion_tecnica),
                es_consumo = COALESCE(:es_consumo, es_consumo),
                es_devolutivo = COALESCE(:es_devolutivo, es_devolutivo),
                es_software = COALESCE(:es_software, es_software),
                es_epp = COALESCE(:es_epp, es_epp)
            WHERE id = :id
        ";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':cantidad' => $cantidad,
            ':observaciones' => $observaciones,
            ':unidad_medida' => $unidadMedida,
            ':descripcion_tecnica' => $descripcionTecnica,
            ':es_consumo' => $esConsumo,
            ':es_devolutivo' => $esDevolutivo,
            ':es_software' => $esSoftware,
            ':es_epp' => $esEpp,
            ':id' => $idDetalle,
        ]);
    }

    /**
     * =========================================================
     * ELIMINAR DETALLE
     * =========================================================
     */
    public function eliminarDetalle(
        int $idDetalle
    ): bool {
        $sql = "
            DELETE FROM materiales_solicitud_detalle
            WHERE id = :id
        ";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            ':id' => $idDetalle,
        ]);
    }

    /**
     * =========================================================
     * DETALLE PERTENECE A SOLICITUD
     * =========================================================
     */
    public function detallePerteneceSolicitud(
        int $idDetalle,
        int $idSolicitud
    ): bool {
        $sql = "
            SELECT COUNT(*)
            FROM materiales_solicitud_detalle
            WHERE
                id = :id_detalle
                AND id_solicitud = :id_solicitud
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id_detalle' => $idDetalle,
            ':id_solicitud' => $idSolicitud,
        ]);

        return (int) $stmt->fetchColumn() > 0;
    }

    /**
     * =========================================================
     * AGREGAR DESTINO
     * =========================================================
     */
    public function agregarDestino(
        int $idDetalle,
        string $tipoDestino,
        ?int $idFicha,
        float $cantidad,
        ?string $observaciones = null
    ): int {
        $sql = "
            INSERT INTO materiales_solicitud_destinos (
                id_detalle_solicitud,
                tipo_destino,
                id_ficha,
                cantidad_destinada,
                observaciones
            )
            VALUES (
                :id_detalle,
                :tipo_destino,
                :id_ficha,
                :cantidad,
                :observaciones
            )
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id_detalle' => $idDetalle,
            ':tipo_destino' => $tipoDestino,
            ':id_ficha' => $idFicha,
            ':cantidad' => $cantidad,
            ':observaciones' => $observaciones,
        ]);

        return (int) $this->db->lastInsertId();
    }

    /**
     * =========================================================
     * CANTIDAD DEL DETALLE
     * =========================================================
     */
    public function obtenerCantidadDetalle(
        int $idDetalle
    ): ?float {
        $sql = "
            SELECT cantidad_solicitada
            FROM materiales_solicitud_detalle
            WHERE id = :id
            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id' => $idDetalle,
        ]);

        $valor = $stmt->fetchColumn();

        if ($valor === false) {
            return null;
        }

        return (float) $valor;
    }

    /**
     * =========================================================
     * TOTAL DESTINADO
     * =========================================================
     */
    public function obtenerTotalDestinado(
        int $idDetalle
    ): float {
        $sql = "
            SELECT
                COALESCE(
                    SUM(cantidad_destinada),
                    0
                )

            FROM materiales_solicitud_destinos

            WHERE id_detalle_solicitud = :id_detalle
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id_detalle' => $idDetalle,
        ]);

        return (float) $stmt->fetchColumn();
    }

    /**
     * =========================================================
     * CAMBIAR ESTADO
     * =========================================================
     */
    public function cambiarEstado(
        int $idSolicitud,
        string $nuevoEstado,
        ?int $idUsuario,
        ?string $observacion = null
    ): bool {
        $estadosPermitidos = [
            'borrador',
            'pendiente_aval',
            'devuelta',
            'avalada',
            'rechazada',
            'cancelada',
        ];

        if (
            !in_array(
                $nuevoEstado,
                $estadosPermitidos,
                true
            )
        ) {
            return false;
        }

        $this->db->beginTransaction();

        try {

            $sqlActual = "
                SELECT estado
                FROM materiales_solicitudes
                WHERE id = :id
                FOR UPDATE
            ";

            $stmtActual = $this->db->prepare(
                $sqlActual
            );

            $stmtActual->execute([
                ':id' => $idSolicitud,
            ]);

            $estadoAnterior =
                $stmtActual->fetchColumn();

            if ($estadoAnterior === false) {

                $this->db->rollBack();

                return false;
            }

            $sqlActualizar = "
                UPDATE materiales_solicitudes
                SET
                    estado = :estado,
                    fecha_envio =
                        CASE
                            WHEN :estado_envio =
                                'pendiente_aval'
                                AND fecha_envio IS NULL
                            THEN NOW()
                            ELSE fecha_envio
                        END,
                    updated_at = NOW()
                WHERE id = :id
            ";

            $stmtActualizar =
                $this->db->prepare(
                    $sqlActualizar
                );

            $stmtActualizar->execute([
                ':estado' => $nuevoEstado,
                ':estado_envio' => $nuevoEstado,
                ':id' => $idSolicitud,
            ]);

            $sqlHistorial = "
                INSERT INTO materiales_solicitud_historial (
                    id_solicitud,
                    estado_anterior,
                    estado_nuevo,
                    id_usuario,
                    observacion
                )
                VALUES (
                    :id_solicitud,
                    :estado_anterior,
                    :estado_nuevo,
                    :id_usuario,
                    :observacion
                )
            ";

            $stmtHistorial =
                $this->db->prepare(
                    $sqlHistorial
                );

            $stmtHistorial->execute([
                ':id_solicitud' => $idSolicitud,
                ':estado_anterior' =>
                    $estadoAnterior,
                ':estado_nuevo' =>
                    $nuevoEstado,
                ':id_usuario' => $idUsuario,
                ':observacion' =>
                    $observacion,
            ]);

            $this->db->commit();

            return true;

        } catch (Throwable $e) {

            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            return false;
        }
    }

    /**
     * =========================================================
     * REGISTRAR DECISIÓN DE AVAL
     * =========================================================
     *
     * Estados permitidos:
     *
     * pendiente_aval → avalada
     * pendiente_aval → devuelta
     *
     * La operación se ejecuta dentro de una transacción y
     * bloquea la solicitud para evitar doble revisión.
     */
    public function registrarDecisionAval(
        int $idSolicitud,
        string $nuevoEstado,
        int $idUsuario,
        ?string $observacion = null
    ): bool {
        if (
            !in_array(
                $nuevoEstado,
                [
                    'avalada',
                    'devuelta',
                ],
                true
            )
        ) {
            return false;
        }

        if (
            $nuevoEstado === 'devuelta'
            &&
            trim(
                (string) $observacion
            ) === ''
        ) {
            return false;
        }

        $this->db->beginTransaction();

        try {

            /*
             * =====================================================
             * BLOQUEAR SOLICITUD
             * =====================================================
             */
            $sqlSolicitud = "
                SELECT
                    id,
                    estado
                FROM materiales_solicitudes
                WHERE id = :id
                FOR UPDATE
            ";

            $stmtSolicitud =
                $this->db->prepare(
                    $sqlSolicitud
                );

            $stmtSolicitud->execute([
                ':id' => $idSolicitud,
            ]);

            $solicitud =
                $stmtSolicitud->fetch(
                    PDO::FETCH_ASSOC
                );

            if (
                !$solicitud
                ||
                ($solicitud['estado'] ?? '')
                    !== 'pendiente_aval'
            ) {

                $this->db->rollBack();

                return false;
            }

            /*
             * =====================================================
             * ACTUALIZAR DECISIÓN
             * =====================================================
             */
            $sqlActualizar = "
                UPDATE materiales_solicitudes
                SET
                    estado = :estado,
                    id_usuario_revision = :id_usuario,
                    fecha_revision = NOW(),
                    observacion_revision = :observacion,
                    updated_at = NOW()
                WHERE
                    id = :id
                    AND estado = 'pendiente_aval'
            ";

            $stmtActualizar =
                $this->db->prepare(
                    $sqlActualizar
                );

            $stmtActualizar->execute([
                ':estado' =>
                    $nuevoEstado,

                ':id_usuario' =>
                    $idUsuario,

                ':observacion' =>
                    $observacion !== null
                        ? trim($observacion)
                        : null,

                ':id' =>
                    $idSolicitud,
            ]);

            if (
                $stmtActualizar->rowCount() !== 1
            ) {

                $this->db->rollBack();

                return false;
            }

            /*
             * =====================================================
             * REGISTRAR HISTORIAL
             * =====================================================
             */
            $sqlHistorial = "
                INSERT INTO materiales_solicitud_historial (
                    id_solicitud,
                    estado_anterior,
                    estado_nuevo,
                    id_usuario,
                    observacion
                )
                VALUES (
                    :id_solicitud,
                    'pendiente_aval',
                    :estado_nuevo,
                    :id_usuario,
                    :observacion
                )
            ";

            $stmtHistorial =
                $this->db->prepare(
                    $sqlHistorial
                );

            $stmtHistorial->execute([
                ':id_solicitud' =>
                    $idSolicitud,

                ':estado_nuevo' =>
                    $nuevoEstado,

                ':id_usuario' =>
                    $idUsuario,

                ':observacion' =>
                    $observacion !== null
                        ? trim($observacion)
                        : null,
            ]);

            $this->db->commit();

            return true;

        } catch (Throwable $e) {

            if (
                $this->db->inTransaction()
            ) {
                $this->db->rollBack();
            }

            return false;
        }
    }

    /**
     * =========================================================
     * REGISTRAR HISTORIAL
     * =========================================================
     */
    public function registrarHistorial(
        int $idSolicitud,
        ?string $estadoAnterior,
        string $estadoNuevo,
        ?int $idUsuario,
        ?string $observacion = null
    ): bool {
        $sql = "
            INSERT INTO materiales_solicitud_historial
            (
                id_solicitud,
                estado_anterior,
                estado_nuevo,
                id_usuario,
                observacion
            )
            VALUES
            (
                :id_solicitud,
                :estado_anterior,
                :estado_nuevo,
                :id_usuario,
                :observacion
            )
        ";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            ':id_solicitud' => $idSolicitud,
            ':estado_anterior' => $estadoAnterior,
            ':estado_nuevo' => $estadoNuevo,
            ':id_usuario' => $idUsuario,
            ':observacion' => $observacion,
        ]);
    }

    /**
     * =========================================================
     * FICHAS DISPONIBLES PARA DESTINOS
     * =========================================================
     */
    public function listarFichasDisponibles(): array
    {
        $sql = "
            SELECT
                id,
                numero_ficha
            FROM fichas
            ORDER BY
                numero_ficha ASC,
                id ASC
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute();

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    /**
     * =========================================================
     * ACTUALIZAR BORRADOR COMPLETO
     * =========================================================
     */
    public function actualizarBorradorCompleto(
        int $idSolicitud,
        string $titulo,
        ?string $justificacion,
        array $detalles
    ): bool {
        $this->db->beginTransaction();

        try {

            $sqlSolicitud = "
                SELECT
                    id,
                    estado
                FROM materiales_solicitudes
                WHERE id = :id
                FOR UPDATE
            ";

            $stmtSolicitud =
                $this->db->prepare(
                    $sqlSolicitud
                );

            $stmtSolicitud->execute([
                ':id' => $idSolicitud,
            ]);

            $solicitud =
                $stmtSolicitud->fetch(
                    PDO::FETCH_ASSOC
                );

            if (
                !$solicitud
                ||
                !in_array(
                    ($solicitud['estado'] ?? ''),
                    [
                        'borrador',
                        'devuelta',
                    ],
                    true
                )
            ) {

                $this->db->rollBack();

                return false;
            }

            $sqlActualizar = "
                UPDATE materiales_solicitudes
                SET
                    titulo = :titulo,
                    justificacion = :justificacion,
                    updated_at = NOW()
                WHERE
                    id = :id
                    AND estado IN (
                        'borrador',
                        'devuelta'
                    )
            ";

            $stmtActualizar =
                $this->db->prepare(
                    $sqlActualizar
                );

            $stmtActualizar->execute([
                ':titulo' =>
                    $titulo,

                ':justificacion' =>
                    $justificacion,

                ':id' =>
                    $idSolicitud,
            ]);

            $sqlDetalles = "
                SELECT id
                FROM materiales_solicitud_detalle
                WHERE id_solicitud = :id_solicitud
            ";

            $stmtDetalles =
                $this->db->prepare(
                    $sqlDetalles
                );

            $stmtDetalles->execute([
                ':id_solicitud' =>
                    $idSolicitud,
            ]);

            $detallesActuales =
                $stmtDetalles->fetchAll(
                    PDO::FETCH_COLUMN
                );

            if (!empty($detallesActuales)) {

                $placeholders = implode(
                    ',',
                    array_fill(
                        0,
                        count($detallesActuales),
                        '?'
                    )
                );

                $sqlEliminarDestinos = "
                    DELETE FROM materiales_solicitud_destinos
                    WHERE id_detalle_solicitud IN (
                        {$placeholders}
                    )
                ";

                $stmtEliminarDestinos =
                    $this->db->prepare(
                        $sqlEliminarDestinos
                    );

                $stmtEliminarDestinos->execute(
                    array_map(
                        'intval',
                        $detallesActuales
                    )
                );
            }

            $sqlEliminarDetalles = "
                DELETE FROM materiales_solicitud_detalle
                WHERE id_solicitud = :id_solicitud
            ";

            $stmtEliminarDetalles =
                $this->db->prepare(
                    $sqlEliminarDetalles
                );

            $stmtEliminarDetalles->execute([
                ':id_solicitud' =>
                    $idSolicitud,
            ]);

            $sqlInsertDetalle = "
                INSERT INTO materiales_solicitud_detalle (
                    id_solicitud, id_material, cantidad_solicitada,
                    observaciones, unidad_medida, descripcion_tecnica,
                    es_consumo, es_devolutivo, es_software, es_epp
                ) VALUES (
                    :id_solicitud, :id_material, :cantidad,
                    :observaciones, :unidad_medida, :descripcion_tecnica,
                    :es_consumo, :es_devolutivo, :es_software, :es_epp
                )
            ";

            $stmtInsertDetalle =
                $this->db->prepare(
                    $sqlInsertDetalle
                );

            $sqlInsertDestino = "
                INSERT INTO materiales_solicitud_destinos (
                    id_detalle_solicitud,
                    tipo_destino,
                    id_ficha,
                    cantidad_destinada,
                    observaciones
                )
                VALUES (
                    :id_detalle,
                    :tipo_destino,
                    :id_ficha,
                    :cantidad,
                    :observaciones
                )
            ";

            $stmtInsertDestino =
                $this->db->prepare(
                    $sqlInsertDestino
                );

            foreach ($detalles as $detalle) {

                $idMaterial =
                    (int) (
                        $detalle['id_material']
                        ?? 0
                    );

                $cantidad =
                    (float) (
                        $detalle['cantidad']
                        ?? 0
                    );

                $observaciones =
                    trim(
                        (string) (
                            $detalle['observaciones']
                            ?? ''
                        )
                    );

                if (
                    $idMaterial <= 0
                    ||
                    $cantidad <= 0
                ) {
                    throw new RuntimeException(
                        'Detalle de material inválido.'
                    );
                }

                $sqlMaterial = "
                    SELECT COUNT(*)
                    FROM materiales_catalogo
                    WHERE
                        id = :id
                        AND estado = 'activo'
                ";

                $stmtMaterial =
                    $this->db->prepare(
                        $sqlMaterial
                    );

                $stmtMaterial->execute([
                    ':id' => $idMaterial,
                ]);

                if (
                    (int) $stmtMaterial->fetchColumn()
                    <= 0
                ) {
                    throw new RuntimeException(
                        'Uno de los materiales ya no está activo.'
                    );
                }

                $stmtInsertDetalle->execute([
                    ':id_solicitud' => $idSolicitud,
                    ':id_material' => $idMaterial,
                    ':cantidad' => $cantidad,
                    ':observaciones' => $observaciones !== '' ? $observaciones : null,
                    ':unidad_medida' => (string) ($detalle['unidad_medida'] ?? 'Unidad'),
                    ':descripcion_tecnica' => (string) ($detalle['descripcion_tecnica'] ?? ''),
                    ':es_consumo' => !empty($detalle['es_consumo']) ? 1 : 0,
                    ':es_devolutivo' => !empty($detalle['es_devolutivo']) ? 1 : 0,
                    ':es_software' => !empty($detalle['es_software']) ? 1 : 0,
                    ':es_epp' => !empty($detalle['es_epp']) ? 1 : 0,
                ]);

                $idDetalle =
                    (int) $this->db->lastInsertId();

                $destinos =
                    $detalle['destinos']
                    ?? [];

                if (
                    !is_array($destinos)
                ) {
                    $destinos = [];
                }

                $totalDestinado = 0.0;

                foreach ($destinos as $destino) {

                    if (
                        !is_array($destino)
                    ) {
                        continue;
                    }

                    $tipoDestino =
                        trim(
                            (string) (
                                $destino['tipo_destino']
                                ?? ''
                            )
                        );

                    $cantidadDestino =
                        (float) (
                            $destino['cantidad_destinada']
                            ?? 0
                        );

                    $observacionDestino =
                        trim(
                            (string) (
                                $destino['observaciones']
                                ?? ''
                            )
                        );

                    if (
                        $cantidadDestino <= 0
                    ) {
                        throw new RuntimeException(
                            'La cantidad destinada debe ser mayor que cero.'
                        );
                    }

                    if (
                        !in_array(
                            $tipoDestino,
                            [
                                'ficha',
                                'general_area',
                            ],
                            true
                        )
                    ) {
                        throw new RuntimeException(
                            'El tipo de destino no es válido.'
                        );
                    }

                    $idFicha = null;

                    if (
                        $tipoDestino === 'ficha'
                    ) {

                        $idFicha =
                            (int) (
                                $destino['id_ficha']
                                ?? 0
                            );

                        if (
                            $idFicha <= 0
                        ) {
                            throw new RuntimeException(
                                'Debe seleccionar una ficha para el destino.'
                            );
                        }

                        $sqlFicha = "
                            SELECT COUNT(*)
                            FROM fichas
                            WHERE id = :id
                        ";

                        $stmtFicha =
                            $this->db->prepare(
                                $sqlFicha
                            );

                        $stmtFicha->execute([
                            ':id' => $idFicha,
                        ]);

                        if (
                            (int) $stmtFicha->fetchColumn()
                            <= 0
                        ) {
                            throw new RuntimeException(
                                'La ficha seleccionada no existe.'
                            );
                        }

                    } else {

                        $idFicha = null;
                    }

                    $totalDestinado +=
                        $cantidadDestino;

                    if (
                        $totalDestinado >
                        $cantidad
                    ) {
                        throw new RuntimeException(
                            'La cantidad destinada no puede superar la cantidad solicitada.'
                        );
                    }

                    $stmtInsertDestino->execute([
                        ':id_detalle' =>
                            $idDetalle,

                        ':tipo_destino' =>
                            $tipoDestino,

                        ':id_ficha' =>
                            $idFicha,

                        ':cantidad' =>
                            $cantidadDestino,

                        ':observaciones' =>
                            $observacionDestino !== ''
                                ? $observacionDestino
                                : null,
                    ]);
                }
            }

            $this->db->commit();

            return true;

        } catch (Throwable $e) {

            if (
                $this->db->inTransaction()
            ) {
                $this->db->rollBack();
            }

            return false;
        }
    }

    /**
     * =========================================================
     * ELIMINAR BORRADOR COMPLETO
     * =========================================================
     */
    public function eliminarBorrador(
        int $idSolicitud
    ): bool {
        $this->db->beginTransaction();

        try {

            $sqlSolicitud = "
                SELECT
                    id,
                    estado
                FROM materiales_solicitudes
                WHERE id = :id
                FOR UPDATE
            ";

            $stmtSolicitud =
                $this->db->prepare(
                    $sqlSolicitud
                );

            $stmtSolicitud->execute([
                ':id' => $idSolicitud,
            ]);

            $solicitud =
                $stmtSolicitud->fetch(
                    PDO::FETCH_ASSOC
                );

            if (
                !$solicitud
                ||
                ($solicitud['estado'] ?? '') !== 'borrador'
            ) {
                $this->db->rollBack();

                return false;
            }

            $sqlDetalles = "
                SELECT id
                FROM materiales_solicitud_detalle
                WHERE id_solicitud = :id
            ";

            $stmtDetalles =
                $this->db->prepare(
                    $sqlDetalles
                );

            $stmtDetalles->execute([
                ':id' => $idSolicitud,
            ]);

            $detalles =
                $stmtDetalles->fetchAll(
                    PDO::FETCH_COLUMN
                );

            if (!empty($detalles)) {

                $placeholders = implode(
                    ',',
                    array_fill(
                        0,
                        count($detalles),
                        '?'
                    )
                );

                $sqlDestinos = "
                    DELETE FROM materiales_solicitud_destinos
                    WHERE id_detalle_solicitud IN (
                        {$placeholders}
                    )
                ";

                $stmtDestinos =
                    $this->db->prepare(
                        $sqlDestinos
                    );

                $stmtDestinos->execute(
                    array_map(
                        'intval',
                        $detalles
                    )
                );
            }

            $sqlEliminarDetalles = "
                DELETE FROM materiales_solicitud_detalle
                WHERE id_solicitud = :id
            ";

            $stmtEliminarDetalles =
                $this->db->prepare(
                    $sqlEliminarDetalles
                );

            $stmtEliminarDetalles->execute([
                ':id' => $idSolicitud,
            ]);

            $sqlHistorial = "
                DELETE FROM materiales_solicitud_historial
                WHERE id_solicitud = :id
            ";

            $stmtHistorial =
                $this->db->prepare(
                    $sqlHistorial
                );

            $stmtHistorial->execute([
                ':id' => $idSolicitud,
            ]);

            $sqlSolicitudDelete = "
                DELETE FROM materiales_solicitudes
                WHERE
                    id = :id
                    AND estado = 'borrador'
            ";

            $stmtSolicitudDelete =
                $this->db->prepare(
                    $sqlSolicitudDelete
                );

            $stmtSolicitudDelete->execute([
                ':id' => $idSolicitud,
            ]);

            if (
                $stmtSolicitudDelete->rowCount() !== 1
            ) {
                throw new RuntimeException(
                    'No fue posible eliminar la solicitud.'
                );
            }

            $this->db->commit();

            return true;

        } catch (Throwable $e) {

            if (
                $this->db->inTransaction()
            ) {
                $this->db->rollBack();
            }

            return false;
        }
    }
}