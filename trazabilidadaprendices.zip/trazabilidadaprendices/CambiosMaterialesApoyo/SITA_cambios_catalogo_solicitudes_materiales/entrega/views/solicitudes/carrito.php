<?php

declare(strict_types=1);

$carrito = is_array($carrito ?? null) ? $carrito : [];
$unidadesMedida = [
    'Unidad', 'Metro', 'Metro Cuadrado', 'Metro Cúbico', 'Centímetro',
    'Centímetro Cuadrado', 'Milímetro', 'Kilogramo', 'Gramo', 'Miligramo',
    'Litro', 'Mililitro', 'Galón', 'Libra', 'Onza', 'Tonelada', 'Pulgada',
    'Pie', 'Yarda', 'Otro',
];
$clasificaciones = [
    'es_consumo' => 'Consumo',
    'es_devolutivo' => 'Devolutivo',
    'es_software' => 'Software',
    'es_epp' => 'EPP',
];
?>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white py-3">
        <div class="d-flex justify-content-between align-items-center gap-3 flex-wrap">
            <div>
                <h5 class="mb-1 fw-semibold"><i class="bi bi-cart3 me-2"></i>Materiales seleccionados</h5>
                <small class="text-muted">Complete la descripción técnica, unidad, clasificación, cantidad y observaciones de cada bien antes de guardar el borrador.</small>
            </div>
            <?php if (!empty($carrito)): ?>
                <form method="POST" action="<?= e(url('/materiales/solicitudes/carrito/vaciar')) ?>" onsubmit="return confirm('¿Está seguro de vaciar todos los materiales seleccionados?');">
                    <?= csrfField() ?>
                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash me-1"></i>Vaciar selección</button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <div class="card-body">
        <?php if (empty($carrito)): ?>
            <div class="text-center py-4 text-muted">
                <i class="bi bi-cart-x" style="font-size:2.5rem;"></i>
                <p class="mb-0 mt-3">Todavía no ha agregado materiales a la solicitud.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th style="min-width:100px;">UNSPSC</th>
                            <th style="min-width:220px;">Material</th>
                            <th style="min-width:180px;">Unidad de medida</th>
                            <th style="min-width:280px;">Descripción técnica requerida del bien</th>
                            <th style="min-width:170px;">Clasificación</th>
                            <th style="width:130px;">Cantidad</th>
                            <th style="min-width:200px;">Observaciones</th>
                            <th class="text-end" style="width:100px;">Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($carrito as $item): ?>
                        <?php
                        $idMaterial = (int) ($item['id_material'] ?? 0);
                        $formActualizar = 'formActualizarMaterial_' . $idMaterial;
                        $cantidadActual = (string) ($item['cantidad'] ?? 1);
                        $observacionesActuales = (string) ($item['observaciones'] ?? '');
                        $unidadActual = (string) ($item['unidad_medida'] ?? '');
                        $descripcionTecnicaActual = (string) ($item['descripcion_tecnica'] ?? '');
                        ?>
                        <tr data-id-material="<?= $idMaterial ?>" class="fila-material-carrito">
                            <td><span class="small"><?= e((string) ($item['codigo_unspsc'] ?? '')) ?></span></td>
                            <td><div class="fw-semibold"><?= e((string) ($item['descripcion'] ?? '')) ?></div></td>
                            <td>
                                <select name="unidad_medida" form="<?= e($formActualizar) ?>" class="form-select form-select-sm campo-unidad-medida-carrito" data-id-material="<?= $idMaterial ?>" required>
                                    <option value="">Seleccione...</option>
                                    <?php foreach ($unidadesMedida as $unidad): ?>
                                        <option value="<?= e($unidad) ?>" <?= $unidadActual === $unidad ? 'selected' : '' ?>><?= e($unidad) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <textarea name="descripcion_tecnica" form="<?= e($formActualizar) ?>" class="form-control form-control-sm campo-descripcion-tecnica-carrito" data-id-material="<?= $idMaterial ?>" rows="3" maxlength="2000" placeholder="Color, tipo, material, modelo, presentación, características..." required><?= e($descripcionTecnicaActual) ?></textarea>
                            </td>
                            <td>
                                <div class="d-flex flex-column gap-1">
                                <?php foreach ($clasificaciones as $campo => $etiqueta): ?>
                                    <label class="form-check mb-0">
                                        <input class="form-check-input campo-clasificacion-carrito" type="checkbox" name="<?= e($campo) ?>" value="1" form="<?= e($formActualizar) ?>" data-id-material="<?= $idMaterial ?>" data-campo="<?= e($campo) ?>" <?= !empty($item[$campo]) ? 'checked' : '' ?>>
                                        <span class="form-check-label"><?= e($etiqueta) ?></span>
                                    </label>
                                <?php endforeach; ?>
                                </div>
                            </td>
                            <td>
                                <input type="number" name="cantidad" form="<?= e($formActualizar) ?>" class="form-control form-control-sm campo-cantidad-carrito" data-id-material="<?= $idMaterial ?>" min="0.01" step="0.01" value="<?= e($cantidadActual) ?>" required>
                            </td>
                            <td>
                                <textarea name="observaciones" form="<?= e($formActualizar) ?>" class="form-control form-control-sm campo-observaciones-carrito" data-id-material="<?= $idMaterial ?>" rows="2" placeholder="Observaciones opcionales"><?= e($observacionesActuales) ?></textarea>
                            </td>
                            <td class="text-end">
                                <form method="POST" action="<?= e(url('/materiales/solicitudes/carrito/actualizar')) ?>" id="<?= e($formActualizar) ?>">
                                    <?= csrfField() ?>
                                    <input type="hidden" name="id_material" value="<?= $idMaterial ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-primary mb-1" title="Actualizar datos del material"><i class="bi bi-check-lg"></i></button>
                                </form>
                                <form method="POST" action="<?= e(url('/materiales/solicitudes/carrito/quitar')) ?>" class="d-inline" onsubmit="return confirm('¿Desea retirar este material de la solicitud?');">
                                    <?= csrfField() ?>
                                    <input type="hidden" name="id_material" value="<?= $idMaterial ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger mb-1" title="Retirar"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="alert alert-light border mb-0">
                <i class="bi bi-info-circle me-2"></i>
                <strong><?= count($carrito) ?></strong> material(es) seleccionado(s).
                <span class="text-muted">Puede actualizar cada fila con el botón ✓ o guardar directamente el borrador.</span>
            </div>
        <?php endif; ?>
    </div>
</div>
