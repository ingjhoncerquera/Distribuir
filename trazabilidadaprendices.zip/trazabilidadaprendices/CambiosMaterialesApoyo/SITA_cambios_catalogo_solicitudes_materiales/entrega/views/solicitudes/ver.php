<?php
declare(strict_types=1);

require_once ROOT_PATH . '/views/layout/header.php';
require_once ROOT_PATH . '/views/layout/navbar.php';
require_once ROOT_PATH . '/core/Auth.php';

$solicitud = is_array($solicitud ?? null) ? $solicitud : [];
$detalles = is_array($detalles ?? null) ? $detalles : [];
$idSolicitud = (int) ($solicitud['id'] ?? 0);
$estado = (string) ($solicitud['estado'] ?? '');
$rutaVolver = (string) ($rutaVolver ?? '/materiales/solicitudes');
$esc = static fn($v): string => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$fechaLegible = static function (?string $f): string {
    if (!$f) return '—';
    $t = strtotime($f);
    return $t === false ? $f : date('d/m/Y H:i', $t);
};
$flashSuccess = $_SESSION['flash_success'] ?? null;
$flashError = $_SESSION['flash_error'] ?? null;
unset($_SESSION['flash_success'], $_SESSION['flash_error']);
$estadoTexto = match ($estado) {
    'borrador' => 'Borrador', 'pendiente_aval' => 'Pendiente de aval',
    'devuelta' => 'Devuelta', 'avalada' => 'Avalada',
    'rechazada' => 'Rechazada', 'cancelada' => 'Cancelada',
    default => ucfirst(str_replace('_', ' ', $estado)),
};
$unidadesPermitidas = ['Unidad','Metro','Metro Cuadrado','Metro Cúbico','Centímetro','Centímetro Cuadrado','Milímetro','Kilogramo','Gramo','Miligramo','Litro','Mililitro','Galón','Libra','Onza','Tonelada','Pulgada','Pie','Yarda','Otro'];
$clasificaciones = ['es_consumo' => 'Consumo', 'es_devolutivo' => 'Devolutivo', 'es_software' => 'Software', 'es_epp' => 'EPP'];
?>
<style>
.solicitud-ver{max-width:1400px;margin:auto}.page-title{font-weight:700;color:#1f2937}.page-subtitle{color:#6b7280}.card-solicitud{border:1px solid #e5e7eb;border-radius:12px;box-shadow:0 2px 8px #0000000a;margin-bottom:20px;overflow:hidden}.card-solicitud>.card-header{background:#f8fafc;border-bottom:1px solid #e5e7eb;padding:16px 20px}.card-solicitud>.card-header h5{margin:0;font-weight:700;color:#1f2937}.card-solicitud>.card-body{padding:20px}.dato-label{display:block;font-size:.78rem;font-weight:700;color:#6b7280;text-transform:uppercase;margin-bottom:4px}.dato-valor{color:#1f2937}.dato-caja{background:#f8fafc;border:1px solid #e5e7eb;border-radius:8px;padding:12px}.estado{display:inline-block;border-radius:999px;padding:6px 11px;font-size:.78rem;font-weight:700;background:#e2e3e5;color:#41464b}.material-card{border:1px solid #e5e7eb;border-radius:10px;padding:16px;margin-bottom:14px}.material-title{font-weight:700;color:#1f2937}.material-code{font-size:.82rem;color:#6b7280}.clasificaciones{display:flex;flex-wrap:wrap;gap:8px}.clasificacion{font-size:.78rem;background:#eef2ff;color:#3730a3;border-radius:999px;padding:5px 9px}.clasificacion.no{background:#f3f4f6;color:#6b7280}.destino-box{background:#f8fafc;border:1px solid #e5e7eb;border-radius:8px;padding:12px;margin-top:12px}.destino-item{padding:7px 0;border-bottom:1px solid #e5e7eb}.destino-item:last-child{border-bottom:0}.dato-tecnico{white-space:pre-wrap;overflow-wrap:anywhere}.texto-ayuda{font-size:.82rem;color:#6b7280}@media(max-width:768px){.card-solicitud>.card-body{padding:14px}.material-card{padding:12px}}
</style>
<main class="container-fluid py-4"><div class="solicitud-ver">
  <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4"><div><h2 class="page-title"><i class="bi bi-file-earmark-text me-2"></i>Consulta de solicitud de materiales</h2><p class="page-subtitle mb-0">Detalle de la solicitud y de los productos seleccionados.</p></div><a href="<?= e(url($rutaVolver)) ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a></div>
  <?php if ($flashSuccess): ?><div class="alert alert-success alert-dismissible fade show"><?= $esc($flashSuccess) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
  <?php if ($flashError): ?><div class="alert alert-danger alert-dismissible fade show"><?= $esc($flashError) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
  <?php if ($idSolicitud <= 0): ?><div class="alert alert-danger">No se pudo identificar la solicitud.</div><?php else: ?>
  <section class="card-solicitud"><div class="card-header"><h5><i class="bi bi-info-circle me-2"></i>Información de la solicitud</h5></div><div class="card-body">
    <div class="row g-3">
      <?php $datos = [
        'Número de solicitud' => $solicitud['numero_solicitud'] ?? 'Sin número',
        'Estado' => $estadoTexto,
        'Fecha de creación' => $fechaLegible((string)($solicitud['created_at'] ?? '')),
        'Proceso' => trim((string)($solicitud['nombre_proceso'] ?? 'Sin proceso') . (($solicitud['anio'] ?? '') !== '' ? ' (' . $solicitud['anio'] . ')' : '')),
        'Área' => $solicitud['nombre_area'] ?? 'Sin área',
        'Profesional solicitante' => trim((string)($solicitud['nombres'] ?? '') . ' ' . (string)($solicitud['apellidos'] ?? '')) ?: 'Sin información',
        'Última actualización' => $fechaLegible((string)($solicitud['updated_at'] ?? '')),
      ]; foreach ($datos as $etiqueta => $valor): ?>
        <div class="col-md-6 col-xl-4"><div class="dato-caja"><span class="dato-label"><?= $esc($etiqueta) ?></span><div class="dato-valor"><?= $esc($valor) ?></div></div></div>
      <?php endforeach; ?>
      <div class="col-12"><span class="dato-label">Título</span><div class="dato-caja"><?= $esc($solicitud['titulo'] ?? '') ?></div></div>
      <div class="col-12"><span class="dato-label">Justificación</span><div class="dato-caja dato-tecnico"><?= nl2br($esc($solicitud['justificacion'] ?? '')) ?></div></div>
      <?php if ($estado === 'devuelta' && trim((string)($solicitud['observacion_revision'] ?? '')) !== ''): ?><div class="col-12"><div class="alert alert-info mb-0"><strong><i class="bi bi-chat-left-text me-1"></i>Observación de la devolución</strong><div class="mt-2"><?= nl2br($esc($solicitud['observacion_revision'])) ?></div></div></div><?php endif; ?>
    </div>
  </div></section>
  <section class="card-solicitud"><div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2"><h5><i class="bi bi-box-seam me-2"></i>Materiales solicitados</h5><span class="badge bg-secondary"><?= count($detalles) ?> <?= count($detalles) === 1 ? 'producto' : 'productos' ?></span></div><div class="card-body">
    <?php if (!$detalles): ?><div class="alert alert-light border mb-0">Esta solicitud no tiene materiales registrados.</div><?php else: ?>
      <?php foreach ($detalles as $i => $detalle):
        $unidad = trim((string)($detalle['unidad_medida'] ?? ''));
        if ($unidad === '') $unidad = 'Unidad';
        $cantidad = $detalle['cantidad_solicitada'] ?? 0;
        $destinosDetalle = is_array($detalle['destinos'] ?? null) ? $detalle['destinos'] : [];
      ?>
      <article class="material-card">
        <div class="row g-3">
          <div class="col-lg-7"><div class="material-title"><?= $esc($detalle['descripcion'] ?? 'Producto sin nombre') ?></div><div class="material-code">Código UNSPSC: <?= $esc($detalle['codigo_unspsc'] ?? '—') ?></div></div>
          <div class="col-sm-6 col-lg-2"><span class="dato-label">Cantidad solicitada</span><div class="dato-valor fw-bold"><?= $esc($cantidad) ?></div></div>
          <div class="col-sm-6 col-lg-3"><span class="dato-label">Unidad de medida</span><div class="dato-valor"><?= $esc($unidad) ?></div></div>
          <div class="col-12"><span class="dato-label">Descripción técnica</span><div class="dato-caja dato-tecnico"><?= trim((string)($detalle['descripcion_tecnica'] ?? '')) !== '' ? nl2br($esc($detalle['descripcion_tecnica'])) : '<span class="text-muted">Sin descripción técnica registrada</span>' ?></div></div>
          <div class="col-12"><span class="dato-label">Clasificación del material</span><div class="clasificaciones"><?php foreach ($clasificaciones as $campo => $nombre): ?><span class="clasificacion <?= !empty($detalle[$campo]) ? '' : 'no' ?>"><?= !empty($detalle[$campo]) ? '<i class="bi bi-check-circle me-1"></i>' : '<i class="bi bi-dash-circle me-1"></i>' ?><?= $esc($nombre) ?><?= !empty($detalle[$campo]) ? '' : ' (No seleccionado)' ?></span><?php endforeach; ?></div></div>
          <div class="col-12"><span class="dato-label">Observaciones</span><div class="dato-caja dato-tecnico"><?= trim((string)($detalle['observaciones'] ?? '')) !== '' ? nl2br($esc($detalle['observaciones'])) : '<span class="text-muted">Sin observaciones</span>' ?></div></div>
          <?php if ($destinosDetalle): ?><div class="col-12"><div class="destino-box"><div class="fw-bold mb-2"><i class="bi bi-geo-alt me-1"></i>Destinos registrados</div><?php foreach ($destinosDetalle as $destino): ?><div class="destino-item"><div class="d-flex justify-content-between gap-3"><span><?php if (($destino['tipo_destino'] ?? '') === 'ficha'): ?><i class="bi bi-people me-1"></i>Ficha <?= $esc(($destino['numero_ficha'] ?? '') !== '' ? $destino['numero_ficha'] : 'Sin número') ?><?php else: ?><i class="bi bi-building me-1"></i>Área general<?php endif; ?></span><strong><?= $esc($destino['cantidad_destinada'] ?? 0) ?></strong></div><?php if (trim((string)($destino['observaciones'] ?? '')) !== ''): ?><div class="text-muted mt-1"><?= nl2br($esc($destino['observaciones'])) ?></div><?php endif; ?></div><?php endforeach; ?></div></div><?php endif; ?>
        </div>
      </article>
      <?php endforeach; ?>
    <?php endif; ?>
  </div></section>
  <?php if (!empty($puedeEditar) || !empty($puedeEnviar)): ?><div class="d-flex flex-wrap justify-content-end gap-2 mb-4"><?php if (!empty($puedeEditar)): ?><a class="btn btn-outline-primary" href="<?= e(url('/materiales/solicitudes/editar?id=' . $idSolicitud)) ?>"><i class="bi bi-pencil-square me-1"></i>Editar materiales</a><?php endif; ?><?php if (!empty($puedeEnviar)): ?><form method="POST" action="<?= e(url('/materiales/solicitudes/enviar')) ?>" onsubmit="return confirm('¿Desea enviar esta solicitud para aval?');"><?= csrfField() ?><input type="hidden" name="id_solicitud" value="<?= $idSolicitud ?>"><button class="btn btn-primary" type="submit"><i class="bi bi-send me-1"></i>Enviar para aval</button></form><?php endif; ?></div><?php endif; ?>
  <?php endif; ?>
</div></main>
<?php require_once ROOT_PATH . '/views/layout/footer.php'; ?>
