<?php

declare(strict_types=1);

if (!class_exists('MaterialesSolicitudController', false)) {

    class MaterialesSolicitudController
    {
        private MaterialesSolicitudModel $model;

        private string $sessionCartKey =
            'materiales_solicitud_carrito';

        /**
         * Datos temporales del encabezado de la solicitud.
         *
         * Se mantienen en sesión mientras el usuario construye
         * la solicitud y navega por el catálogo.
         */
        private string $sessionFormKey =
            'materiales_solicitud_formulario';

        public function __construct()
        {
            Auth::requireLogin();

            $this->model =
                new MaterialesSolicitudModel();

            /*
             * =====================================================
             * INICIALIZAR CARRITO
             * =====================================================
             */
            if (
                !isset(
                    $_SESSION[
                        $this->sessionCartKey
                    ]
                )
                ||
                !is_array(
                    $_SESSION[
                        $this->sessionCartKey
                    ]
                )
            ) {
                $_SESSION[
                    $this->sessionCartKey
                ] = [];
            }

            /*
             * =====================================================
             * INICIALIZAR FORMULARIO TEMPORAL
             * =====================================================
             */
            if (
                !isset(
                    $_SESSION[
                        $this->sessionFormKey
                    ]
                )
                ||
                !is_array(
                    $_SESSION[
                        $this->sessionFormKey
                    ]
                )
            ) {
                $_SESSION[
                    $this->sessionFormKey
                ] = [
                    'id_proceso' =>
                        0,

                    'id_proceso_area' =>
                        0,

                    'titulo' =>
                        '',

                    'justificacion' =>
                        '',
                ];
            }
        }

        /**
         * =========================================================
         * LISTADO DE SOLICITUDES PROPIAS
         * =========================================================
         */
        public function index(): void
        {
            $this->exigirPermiso(
                'materiales.solicitudes.crear'
            );

            $profesional =
                $this->profesionalActual();

            if (!$profesional) {

                /*
                 * Un Administrador sin profesional asociado no tiene
                 * "solicitudes propias": se le envía a la bandeja
                 * de gestión (aval).
                 */
                if (Auth::hasRole('Administrador')) {

                    $this->redirect(
                        '/materiales/solicitudes/aval'
                    );
                }

                $this->error(
                    'El usuario actual no tiene un profesional activo asociado.'
                );
            }

            $idProfesional =
                (int) $profesional['id'];

            $solicitudes =
                $this->model->listarPorProfesional(
                    $idProfesional
                );

            require ROOT_PATH .
                '/views/solicitudes/index.php';
        }

        /**
         * =========================================================
         * CREAR SOLICITUD
         * =========================================================
         */
        public function crear(): void
        {
            $this->exigirPermiso(
                'materiales.solicitudes.crear'
            );

            $profesional =
                $this->exigirProfesional();

            $idProfesional =
                (int) $profesional['id'];

            $carrito =
                $this->obtenerCarrito();

            $procesos =
                $this->model->listarProcesosDisponibles();

            /*
             * =====================================================
             * RECUPERAR DATOS TEMPORALES DEL ENCABEZADO
             * =====================================================
             */
            $formulario =
                $this->obtenerFormularioTemporal();

            /*
             * =====================================================
             * PROCESO DESDE GET
             * =====================================================
             */
            if (isset($_GET['id_proceso'])) {

                $idProcesoRecibido =
                    (int) $_GET['id_proceso'];

                $idProcesoAnterior =
                    (int) (
                        $formulario['id_proceso']
                        ?? 0
                    );

                $formulario['id_proceso'] =
                    $idProcesoRecibido;

                if (
                    $idProcesoRecibido !==
                    $idProcesoAnterior
                ) {
                    $formulario['id_proceso_area'] =
                        0;
                }
            }

            $idProceso =
                (int) (
                    $formulario['id_proceso']
                    ?? 0
                );

            /*
             * =====================================================
             * DATOS RECIBIDOS DESDE GET
             * =====================================================
             */
            if (isset($_GET['id_proceso_area'])) {

                $formulario['id_proceso_area'] =
                    (int) $_GET['id_proceso_area'];
            }

            if (isset($_GET['titulo'])) {

                $formulario['titulo'] =
                    trim(
                        (string) $_GET['titulo']
                    );
            }

            if (isset($_GET['justificacion'])) {

                $formulario['justificacion'] =
                    trim(
                        (string) $_GET['justificacion']
                    );
            }

            /*
             * =====================================================
             * DATOS RECIBIDOS DESDE POST
             * =====================================================
             */
            if (isset($_POST['id_proceso'])) {

                $formulario['id_proceso'] =
                    (int) $_POST['id_proceso'];

                $idProceso =
                    (int) $formulario['id_proceso'];
            }

            if (isset($_POST['id_proceso_area'])) {

                $formulario['id_proceso_area'] =
                    (int) $_POST['id_proceso_area'];
            }

            if (isset($_POST['titulo'])) {

                $formulario['titulo'] =
                    trim(
                        (string) $_POST['titulo']
                    );
            }

            if (isset($_POST['justificacion'])) {

                $formulario['justificacion'] =
                    trim(
                        (string) $_POST['justificacion']
                    );
            }

            /*
             * =====================================================
             * GUARDAR DATOS TEMPORALES
             * =====================================================
             */
            $this->guardarFormularioTemporal(
                $formulario
            );

            /*
             * =====================================================
             * VARIABLES PARA LA VISTA
             * =====================================================
             */
            $idProcesoArea =
                (int) (
                    $formulario['id_proceso_area']
                    ?? 0
                );

            $tituloSolicitud =
                (string) (
                    $formulario['titulo']
                    ?? ''
                );

            $justificacionSolicitud =
                (string) (
                    $formulario['justificacion']
                    ?? ''
                );

            /*
             * =====================================================
             * ÁREAS ASIGNADAS AL PROFESIONAL
             * =====================================================
             */
            $areas = [];

            if ($idProceso > 0) {

                $areas =
                    $this->model->listarAreasPorProceso(
                        $idProceso,
                        $idProfesional
                    );
            }

            /*
             * =====================================================
             * BUSCADOR
             * =====================================================
             */
            $buscar =
                trim(
                    (string) (
                        $_GET['buscar']
                        ?? $_POST['buscar']
                        ?? ''
                    )
                );

            /*
             * =====================================================
             * PAGINACIÓN
             * =====================================================
             */
            $pagina =
                max(
                    1,
                    (int) (
                        $_GET['pagina']
                        ?? $_POST['pagina']
                        ?? 1
                    )
                );

            $porPagina = 20;

            $total =
                $this->model->contarMaterialesActivos(
                    $buscar
                );

            $totalPaginas =
                max(
                    1,
                    (int) ceil(
                        $total / $porPagina
                    )
                );

            if ($pagina > $totalPaginas) {

                $pagina =
                    $totalPaginas;
            }

            $offset =
                ($pagina - 1) * $porPagina;

            /*
             * =====================================================
             * MATERIALES
             * =====================================================
             */
            $materiales =
                $this->model->listarMaterialesActivos(
                    $buscar,
                    $porPagina,
                    $offset
                );

            /*
             * =====================================================
             * VISTA
             * =====================================================
             */
            require ROOT_PATH .
                '/views/solicitudes/crear.php';
        }

        /**
         * =========================================================
         * CARGAR ÁREAS POR AJAX
         * =========================================================
         */
        public function cargarAreas(): void
        {
            $this->exigirPermiso(
                'materiales.solicitudes.crear'
            );

            header(
                'Content-Type: application/json; charset=utf-8'
            );

            try {

                $profesional =
                    $this->exigirProfesional();

                $idProfesional =
                    (int) $profesional['id'];

                $idProceso =
                    isset($_GET['id_proceso'])
                        ? (int) $_GET['id_proceso']
                        : 0;

                if ($idProceso <= 0) {

                    echo json_encode(
                        [
                            'ok' => false,
                            'areas' => [],
                            'mensaje' =>
                                'Debe seleccionar un proceso.'
                        ],
                        JSON_UNESCAPED_UNICODE
                    );

                    return;
                }

                $proceso =
                    $this->model->obtenerProceso(
                        $idProceso
                    );

                if (!$proceso) {

                    echo json_encode(
                        [
                            'ok' => false,
                            'areas' => [],
                            'mensaje' =>
                                'El proceso seleccionado no existe.'
                        ],
                        JSON_UNESCAPED_UNICODE
                    );

                    return;
                }

                $formulario =
                    $this->obtenerFormularioTemporal();

                $formulario['id_proceso'] =
                    $idProceso;

                $formulario['id_proceso_area'] =
                    0;

                $this->guardarFormularioTemporal(
                    $formulario
                );

                $areas =
                    $this->model->listarAreasPorProceso(
                        $idProceso,
                        $idProfesional
                    );

                echo json_encode(
                    [
                        'ok' => true,
                        'areas' => $areas,
                    ],
                    JSON_UNESCAPED_UNICODE
                );

            } catch (Throwable $e) {

                echo json_encode(
                    [
                        'ok' => false,
                        'areas' => [],
                        'mensaje' =>
                            'No fue posible cargar las áreas.'
                    ],
                    JSON_UNESCAPED_UNICODE
                );
            }
        }

        /**
         * =========================================================
         * AGREGAR MATERIAL AL CARRITO
         * =========================================================
         */
        public function agregarMaterial(): void
        {
            $this->exigirPermiso(
                'materiales.solicitudes.crear'
            );

            $this->validarPost();

            $this->actualizarFormularioDesdePost();

            $idMaterial =
                (int) (
                    $_POST['id_material']
                    ?? 0
                );

            $cantidad =
                (float) (
                    $_POST['cantidad']
                    ?? 1
                );

            $buscar =
                trim(
                    (string) (
                        $_POST['buscar']
                        ?? ''
                    )
                );

            $pagina =
                max(
                    1,
                    (int) (
                        $_POST['pagina']
                        ?? 1
                    )
                );

            if ($idMaterial <= 0) {

                $this->flashError(
                    'El material seleccionado no es válido.'
                );

                $this->redirectCrear(
                    $buscar,
                    $pagina
                );
            }

            if ($cantidad <= 0) {

                $cantidad = 1;
            }

            $material =
                $this->model->obtenerMaterialActivo(
                    $idMaterial
                );

            if (!$material) {

                $this->flashError(
                    'El material seleccionado no está disponible.'
                );

                $this->redirectCrear(
                    $buscar,
                    $pagina
                );
            }

            $carrito =
                $this->obtenerCarrito();

            if (
                isset(
                    $carrito[$idMaterial]
                )
                &&
                is_array(
                    $carrito[$idMaterial]
                )
            ) {

                $carrito[$idMaterial]['cantidad'] =
                    max(
                        0.01,
                        $cantidad
                    );

            } else {

                $carrito[$idMaterial] = [
                    'id' =>
                        $idMaterial,

                    'id_material' =>
                        $idMaterial,

                    'codigo_unspsc' =>
                        (string) (
                            $material['codigo_unspsc']
                            ?? ''
                        ),

                    'descripcion' =>
                        (string) (
                            $material['descripcion']
                            ?? ''
                        ),

                    'unidad_medida' => '',
                    'descripcion_tecnica' => '',
                    'es_consumo' => 0,
                    'es_devolutivo' => 0,
                    'es_software' => 0,
                    'es_epp' => 0,
                    'cantidad' => $cantidad,
                    'observaciones' => '',
                ];
            }

            $this->guardarCarrito(
                $carrito
            );

            $this->flashSuccess(
                'Material agregado a la solicitud.'
            );

            $this->redirectCrear(
                $buscar,
                $pagina
            );
        }

        /**
         * =========================================================
         * ACTUALIZAR CARRITO
         * =========================================================
         */
        public function actualizarCarrito(): void
        {
            $this->exigirPermiso(
                'materiales.solicitudes.crear'
            );

            $this->validarPost();

            $this->actualizarFormularioDesdePost();

            $carrito =
                $this->obtenerCarrito();

            $idMaterial =
                (int) (
                    $_POST['id_material']
                    ?? 0
                );

            $cantidadRecibida =
                $_POST['cantidad']
                ?? null;

            $observacionRecibida =
                $_POST['observaciones']
                ?? '';

            if (
                $idMaterial <= 0
                ||
                !isset(
                    $carrito[$idMaterial]
                )
                ||
                !is_array(
                    $carrito[$idMaterial]
                )
            ) {

                $this->flashError(
                    'El material seleccionado no se encuentra en el carrito.'
                );

                $this->redirect(
                    '/materiales/solicitudes/crear'
                );
            }

            if (
                is_array($cantidadRecibida)
            ) {

                $cantidad =
                    isset(
                        $cantidadRecibida[$idMaterial]
                    )
                        ? (float) $cantidadRecibida[
                            $idMaterial
                        ]
                        : 0;

            } else {

                $cantidad =
                    (float) $cantidadRecibida;
            }

            if ($cantidad <= 0) {

                $this->flashError(
                    'La cantidad debe ser mayor que cero.'
                );

                $this->redirect(
                    '/materiales/solicitudes/crear'
                );
            }

            if (
                is_array($observacionRecibida)
            ) {

                $observaciones =
                    trim(
                        (string) (
                            $observacionRecibida[
                                $idMaterial
                            ]
                            ?? ''
                        )
                    );

            } else {

                $observaciones =
                    trim(
                        (string) $observacionRecibida
                    );
            }

            $unidadMedida = trim((string) ($_POST['unidad_medida'] ?? ''));
            $unidadesPermitidas = [
                'Unidad', 'Metro', 'Metro Cuadrado', 'Metro Cúbico',
                'Centímetro', 'Centímetro Cuadrado', 'Milímetro',
                'Kilogramo', 'Gramo', 'Miligramo', 'Litro', 'Mililitro',
                'Galón', 'Libra', 'Onza', 'Tonelada', 'Pulgada', 'Pie',
                'Yarda', 'Otro',
            ];
            $descripcionTecnica = trim((string) ($_POST['descripcion_tecnica'] ?? ''));

            if (!in_array($unidadMedida, $unidadesPermitidas, true)) {
                $this->flashError('Seleccione una unidad de medida válida.');
                $this->redirect('/materiales/solicitudes/crear');
            }
            if ($descripcionTecnica === '') {
                $this->flashError('La descripción técnica del bien es obligatoria.');
                $this->redirect('/materiales/solicitudes/crear');
            }

            $carrito[$idMaterial]['cantidad'] = $cantidad;
            $carrito[$idMaterial]['observaciones'] = $observaciones;
            $carrito[$idMaterial]['unidad_medida'] = $unidadMedida;
            $carrito[$idMaterial]['descripcion_tecnica'] = $descripcionTecnica;
            foreach (['es_consumo', 'es_devolutivo', 'es_software', 'es_epp'] as $campoClasificacion) {
                $carrito[$idMaterial][$campoClasificacion] =
                    isset($_POST[$campoClasificacion]) && (string) $_POST[$campoClasificacion] === '1' ? 1 : 0;
            }

            $this->guardarCarrito(
                $carrito
            );

            $this->flashSuccess(
                'Los datos del material fueron actualizados correctamente.'
            );

            $this->redirect(
                '/materiales/solicitudes/crear'
            );
        }

        /**
         * =========================================================
         * QUITAR MATERIAL DEL CARRITO
         * =========================================================
         */
        public function quitarMaterial(): void
        {
            $this->exigirPermiso(
                'materiales.solicitudes.crear'
            );

            $this->validarPost();

            $this->actualizarFormularioDesdePost();

            $idMaterial =
                (int) (
                    $_POST['id_material']
                    ?? 0
                );

            $carrito =
                $this->obtenerCarrito();

            if (
                $idMaterial > 0
                &&
                isset(
                    $carrito[$idMaterial]
                )
            ) {

                unset(
                    $carrito[$idMaterial]
                );

                $this->guardarCarrito(
                    $carrito
                );
            }

            $this->flashSuccess(
                'Material retirado de la solicitud.'
            );

            $this->redirect(
                '/materiales/solicitudes/crear'
            );
        }

        /**
         * =========================================================
         * VACIAR CARRITO
         * =========================================================
         */
        public function vaciarCarrito(): void
        {
            $this->exigirPermiso(
                'materiales.solicitudes.crear'
            );

            $this->validarPost();

            $this->guardarCarrito([]);

            $this->flashSuccess(
                'El carrito fue vaciado.'
            );

            $this->redirect(
                '/materiales/solicitudes/crear'
            );
        }

        /**
         * =========================================================
         * GUARDAR BORRADOR
         * =========================================================
         */
        public function guardarBorrador(): void
        {
            $this->exigirPermiso(
                'materiales.solicitudes.crear'
            );

            $this->validarPost();

            $this->actualizarFormularioDesdePost();

            $materialesPost =
                $_POST['materiales']
                ?? [];

            if (
                is_array($materialesPost)
                &&
                !empty($materialesPost)
            ) {

                $carrito =
                    $this->obtenerCarrito();

                foreach (
                    $materialesPost as $idMaterialPost => $materialPost
                ) {

                    $idMaterialPost =
                        (int) $idMaterialPost;

                    if (
                        $idMaterialPost <= 0
                        ||
                        !is_array($materialPost)
                        ||
                        !isset(
                            $carrito[$idMaterialPost]
                        )
                        ||
                        !is_array(
                            $carrito[$idMaterialPost]
                        )
                    ) {
                        continue;
                    }

                    $cantidadPost =
                        (float) (
                            $materialPost['cantidad']
                            ?? 0
                        );

                    if ($cantidadPost > 0) {

                        $carrito[
                            $idMaterialPost
                        ]['cantidad'] =
                            $cantidadPost;
                    }

                    if (
                        array_key_exists(
                            'observaciones',
                            $materialPost
                        )
                    ) {

                        $carrito[
                            $idMaterialPost
                        ]['observaciones'] =
                            trim(
                                (string) (
                                    $materialPost[
                                        'observaciones'
                                    ]
                                    ?? ''
                                )
                            );
                    }

                    $unidadPost = trim((string) ($materialPost['unidad_medida'] ?? ''));
                    $descripcionTecnicaPost = trim((string) ($materialPost['descripcion_tecnica'] ?? ''));
                    $unidadesPermitidas = [
                        'Unidad', 'Metro', 'Metro Cuadrado', 'Metro Cúbico',
                        'Centímetro', 'Centímetro Cuadrado', 'Milímetro',
                        'Kilogramo', 'Gramo', 'Miligramo', 'Litro', 'Mililitro',
                        'Galón', 'Libra', 'Onza', 'Tonelada', 'Pulgada', 'Pie',
                        'Yarda', 'Otro',
                    ];
                    $carrito[$idMaterialPost]['unidad_medida'] =
                        in_array($unidadPost, $unidadesPermitidas, true) ? $unidadPost : '';
                    $carrito[$idMaterialPost]['descripcion_tecnica'] = $descripcionTecnicaPost;
                    foreach (['es_consumo', 'es_devolutivo', 'es_software', 'es_epp'] as $campoClasificacion) {
                        $carrito[$idMaterialPost][$campoClasificacion] =
                            !empty($materialPost[$campoClasificacion]) ? 1 : 0;
                    }
                }

                $this->guardarCarrito(
                    $carrito
                );
            }

            $profesional =
                $this->exigirProfesional();

            $idProfesional =
                (int) $profesional['id'];

            $idProcesoArea =
                (int) (
                    $_POST['id_proceso_area']
                    ?? 0
                );

            $titulo =
                trim(
                    (string) (
                        $_POST['titulo']
                        ?? ''
                    )
                );

            $justificacion =
                trim(
                    (string) (
                        $_POST['justificacion']
                        ?? ''
                    )
                );

            if ($idProcesoArea <= 0) {

                $this->flashError(
                    'Debe seleccionar un área responsable.'
                );

                $this->redirect(
                    '/materiales/solicitudes/crear'
                );
            }

            if ($titulo === '') {

                $this->flashError(
                    'Debe ingresar el título de la solicitud.'
                );

                $this->redirect(
                    '/materiales/solicitudes/crear'
                );
            }

            $area =
                $this->model->obtenerArea(
                    $idProcesoArea
                );

            if (
                !$area
                ||
                ($area['estado'] ?? '') !== 'activa'
            ) {

                $this->flashError(
                    'El área seleccionada no existe o no está activa.'
                );

                $this->redirect(
                    '/materiales/solicitudes/crear'
                );
            }

            $esResponsable =
                $this->model->profesionalEsResponsableArea(
                    $idProcesoArea,
                    $idProfesional
                );

            if (!$esResponsable) {

                $this->flashError(
                    'No está autorizado para realizar solicitudes en el área seleccionada.'
                );

                $this->redirect(
                    '/materiales/solicitudes/crear'
                );
            }

            $carrito =
                $this->obtenerCarrito();

            if (empty($carrito)) {

                $this->flashError(
                    'Debe agregar al menos un material a la solicitud.'
                );

                $this->redirect(
                    '/materiales/solicitudes/crear'
                );
            }

            $detalles = [];

            foreach (
                $carrito as $idMaterial => $item
            ) {

                $idMaterial =
                    (int) $idMaterial;

                if ($idMaterial <= 0) {
                    continue;
                }

                $material =
                    $this->model->obtenerMaterialActivo(
                        $idMaterial
                    );

                if (!$material) {

                    $this->flashError(
                        'Uno de los materiales seleccionados ya no está activo. Revise el carrito.'
                    );

                    $this->redirect(
                        '/materiales/solicitudes/crear'
                    );
                }

                $cantidad =
                    (float) (
                        $item['cantidad']
                        ?? 0
                    );

                if ($cantidad <= 0) {

                    $this->flashError(
                        'Todas las cantidades solicitadas deben ser mayores que cero.'
                    );

                    $this->redirect(
                        '/materiales/solicitudes/crear'
                    );
                }

                $observaciones =
                    trim(
                        (string) (
                            $item['observaciones']
                            ?? ''
                        )
                    );

                $unidadMedida = trim((string) ($item['unidad_medida'] ?? ''));
                $descripcionTecnica = trim((string) ($item['descripcion_tecnica'] ?? ''));
                $unidadesPermitidas = [
                    'Unidad', 'Metro', 'Metro Cuadrado', 'Metro Cúbico',
                    'Centímetro', 'Centímetro Cuadrado', 'Milímetro',
                    'Kilogramo', 'Gramo', 'Miligramo', 'Litro', 'Mililitro',
                    'Galón', 'Libra', 'Onza', 'Tonelada', 'Pulgada', 'Pie',
                    'Yarda', 'Otro',
                ];
                if (!in_array($unidadMedida, $unidadesPermitidas, true)) {
                    $this->flashError('Seleccione la unidad de medida de cada material.');
                    $this->redirect('/materiales/solicitudes/crear');
                }
                if ($descripcionTecnica === '') {
                    $this->flashError('Complete la descripción técnica requerida de cada bien.');
                    $this->redirect('/materiales/solicitudes/crear');
                }

                $detalles[] = [
                    'id_material' => $idMaterial,
                    'cantidad' => $cantidad,
                    'observaciones' => $observaciones,
                    'unidad_medida' => $unidadMedida,
                    'descripcion_tecnica' => $descripcionTecnica,
                    'es_consumo' => !empty($item['es_consumo']) ? 1 : 0,
                    'es_devolutivo' => !empty($item['es_devolutivo']) ? 1 : 0,
                    'es_software' => !empty($item['es_software']) ? 1 : 0,
                    'es_epp' => !empty($item['es_epp']) ? 1 : 0,
                ];
            }

            if (empty($detalles)) {

                $this->flashError(
                    'No hay materiales válidos para guardar.'
                );

                $this->redirect(
                    '/materiales/solicitudes/crear'
                );
            }

            try {

                $idSolicitud =
                    $this->model->crearBorrador(
                        $idProcesoArea,
                        $idProfesional,
                        $titulo,
                        $justificacion !== ''
                            ? $justificacion
                            : null
                    );

                foreach ($detalles as $detalle) {

                    $this->model->agregarDetalle(
                        $idSolicitud,
                        (int) $detalle['id_material'],
                        (float) $detalle['cantidad'],
                        $detalle['observaciones'] !== ''
                            ? $detalle['observaciones']
                            : null,
                        (string) $detalle['unidad_medida'],
                        (string) $detalle['descripcion_tecnica'],
                        (int) $detalle['es_consumo'],
                        (int) $detalle['es_devolutivo'],
                        (int) $detalle['es_software'],
                        (int) $detalle['es_epp']
                    );
                }

                $idUsuario =
                    $this->obtenerUsuarioActualId();

                $this->model->registrarHistorial(
                    $idSolicitud,
                    null,
                    'borrador',
                    $idUsuario,
                    'Solicitud creada como borrador.'
                );

                $this->guardarCarrito([]);

                $this->limpiarFormularioTemporal();

                $this->flashSuccess(
                    'La solicitud fue guardada correctamente como borrador.'
                );

                $this->redirect(
                    '/materiales/solicitudes'
                );

            } catch (Throwable $e) {

                $this->flashError(
                    'No fue posible guardar la solicitud. Verifique la información e inténtelo nuevamente.'
                );

                $this->redirect(
                    '/materiales/solicitudes/crear'
                );
            }
        }

        /**
         * =========================================================
         * VER SOLICITUD
         * =========================================================
         */
        public function ver(): void
        {
            $idSolicitud =
                (int) (
                    $_GET['id']
                    ?? $_GET['id_solicitud']
                    ?? 0
                );

            if ($idSolicitud <= 0) {

                $this->error(
                    'Solicitud no válida.'
                );
            }

            $solicitud =
                $this->model->obtenerSolicitud(
                    $idSolicitud
                );

            if (!$solicitud) {

                $this->error(
                    'La solicitud no existe.'
                );
            }

            $profesional =
                $this->profesionalActual();

            $idProfesionalActual =
                $profesional
                    ? (int) $profesional['id']
                    : 0;

            $esPropietario =
                $idProfesionalActual > 0
                &&
                (int) (
                    $solicitud[
                        'id_profesional_solicitante'
                    ] ?? 0
                ) === $idProfesionalActual;

            $esAdministrador =
                Auth::hasRole('Administrador');

            $puedeRevisar =
                false;

            if (
                !$esPropietario
                &&
                !$esAdministrador
                &&
                $idProfesionalActual > 0
            ) {

                $puedeRevisar =
                    $this->model->coordinadorPuedeRevisarSolicitud(
                        $idSolicitud,
                        $idProfesionalActual
                    );
            }

            if (
                !$esPropietario
                &&
                !$esAdministrador
                &&
                !$puedeRevisar
            ) {

                $this->error(
                    'No tiene autorización para consultar esta solicitud.'
                );
            }

            /*
             * =====================================================
             * RUTA DEL BOTÓN VOLVER
             * =====================================================
             *
             * El solicitante vuelve a "Mis solicitudes".
             * El Administrador o Coordinador que revisa
             * vuelve a la bandeja de aval, porque no siempre
             * tienen un profesional activo asociado.
             */
            $rutaVolver =
                $esPropietario
                    ? '/materiales/solicitudes'
                    : '/materiales/solicitudes/aval';

            $puedeEditar =
                $esPropietario
                && in_array(
                    (string) ($solicitud['estado'] ?? ''),
                    ['borrador', 'devuelta'],
                    true
                );

            $puedeEnviar =
                $puedeEditar
                && Auth::can('materiales.solicitudes.crear');

            $detalles =
                $this->model->listarDetalles(
                    $idSolicitud
                );

            foreach ($detalles as &$detalle) {

                $idDetalle =
                    (int) (
                        $detalle['id']
                        ?? $detalle['id_detalle']
                        ?? 0
                    );

                $detalle['destinos'] = [];

                if ($idDetalle > 0) {

                    $detalle['destinos'] =
                        $this->model->listarDestinosPorDetalle(
                            $idDetalle
                        );
                }
            }

            unset($detalle);

            require ROOT_PATH .
                '/views/solicitudes/ver.php';
        }

        /**
         * =========================================================
         * ENVIAR SOLICITUD A AVAL
         * =========================================================
         */
        public function enviar(): void
        {
            $this->exigirPermiso(
                'materiales.solicitudes.crear'
            );

            $this->validarPost();

            $profesional =
                $this->exigirProfesional();

            $idProfesional =
                (int) $profesional['id'];

            $idSolicitud =
                (int) (
                    $_POST['id_solicitud']
                    ?? $_POST['id']
                    ?? $_POST['solicitud_id']
                    ?? 0
                );

            if ($idSolicitud <= 0) {

                $this->flashError(
                    'Solicitud no válida.'
                );

                $this->redirect(
                    '/materiales/solicitudes'
                );
            }

            $solicitud =
                $this->model->obtenerSolicitud(
                    $idSolicitud
                );

            if (!$solicitud) {

                $this->flashError(
                    'La solicitud no existe.'
                );

                $this->redirect(
                    '/materiales/solicitudes'
                );
            }

            if (
                (int) (
                    $solicitud[
                        'id_profesional_solicitante'
                    ] ?? 0
                ) !== $idProfesional
            ) {

                $this->flashError(
                    'No está autorizado para enviar esta solicitud.'
                );

                $this->redirect(
                    '/materiales/solicitudes'
                );
            }

            $estadoActual =
                (string) (
                    $solicitud['estado']
                    ?? ''
                );

            if (
                !in_array(
                    $estadoActual,
                    [
                        'borrador',
                        'devuelta',
                    ],
                    true
                )
            ) {

                $this->flashError(
                    'La solicitud no puede ser enviada en su estado actual.'
                );

                $this->redirect(
                    '/materiales/solicitudes/ver?id=' .
                    $idSolicitud
                );
            }

            $detalles =
                $this->model->listarDetalles(
                    $idSolicitud
                );

            if (empty($detalles)) {

                $this->flashError(
                    'No se puede enviar una solicitud sin materiales.'
                );

                $this->redirect(
                    '/materiales/solicitudes/ver?id=' .
                    $idSolicitud
                );
            }

            foreach ($detalles as $detalle) {

                $cantidad =
                    (float) (
                        $detalle[
                            'cantidad_solicitada'
                        ]
                        ?? 0
                    );

                if ($cantidad <= 0) {

                    $this->flashError(
                        'Todas las cantidades solicitadas deben ser mayores que cero.'
                    );

                    $this->redirect(
                        '/materiales/solicitudes/ver?id=' .
                        $idSolicitud
                    );
                }

                $idMaterial =
                    (int) (
                        $detalle['id_material']
                        ?? 0
                    );

                if (
                    $idMaterial <= 0
                    ||
                    !$this->model->obtenerMaterialActivo(
                        $idMaterial
                    )
                ) {

                    $this->flashError(
                        'Uno de los materiales de la solicitud ya no está activo.'
                    );

                    $this->redirect(
                        '/materiales/solicitudes/ver?id=' .
                        $idSolicitud
                    );
                }
            }

            $idUsuario =
                $this->obtenerUsuarioActualId();

            $observacion =
                $estadoActual === 'devuelta'
                    ? 'Solicitud corregida y reenviada para aval.'
                    : 'Solicitud enviada para aval.';

            $resultado =
                $this->model->cambiarEstado(
                    $idSolicitud,
                    'pendiente_aval',
                    $idUsuario,
                    $observacion
                );

            if (!$resultado) {

                $this->flashError(
                    'No fue posible enviar la solicitud para aval.'
                );

                $this->redirect(
                    '/materiales/solicitudes/ver?id=' .
                    $idSolicitud
                );
            }

            $this->flashSuccess(
                'La solicitud fue enviada correctamente y quedó pendiente de aval.'
            );

            $this->redirect(
                '/materiales/solicitudes'
            );
        }

        /**
         * =========================================================
         * EDITAR BORRADOR O SOLICITUD DEVUELTA
         * =========================================================
         */
        public function editar(): void
        {
            $this->exigirPermiso(
                'materiales.solicitudes.crear'
            );

            $idSolicitud =
                (int) (
                    $_GET['id']
                    ?? $_GET['id_solicitud']
                    ?? 0
                );

            if ($idSolicitud <= 0) {

                $this->error(
                    'Solicitud no válida.'
                );
            }

            $solicitud =
                $this->model->obtenerSolicitud(
                    $idSolicitud
                );

            if (!$solicitud) {

                $this->error(
                    'La solicitud no existe.'
                );
            }

            /*
             * =====================================================
             * SOLO BORRADORES O DEVUELTAS
             * =====================================================
             */
            if (
                !in_array(
                    ($solicitud['estado'] ?? ''),
                    [
                        'borrador',
                        'devuelta',
                    ],
                    true
                )
            ) {

                $this->error(
                    'Solo se pueden editar solicitudes en estado borrador o devuelta.'
                );
            }

            /*
             * =====================================================
             * AUTORIZACIÓN
             * =====================================================
             *
             * El Coordinador NO edita solicitudes de terceros.
             * Solamente el profesional solicitante o Administrador.
             */
            $profesional =
                $this->profesionalActual();

            $idProfesionalActual =
                $profesional
                    ? (int) $profesional['id']
                    : 0;

            $esPropietario =
                $idProfesionalActual > 0
                &&
                (int) (
                    $solicitud[
                        'id_profesional_solicitante'
                    ] ?? 0
                ) === $idProfesionalActual;

            $esAdministrador =
                Auth::hasRole('Administrador');

            if (
                !$esPropietario
                &&
                !$esAdministrador
            ) {

                $this->error(
                    'No tiene autorización para editar esta solicitud.'
                );
            }

            $detalles =
                $this->model->listarDetalles(
                    $idSolicitud
                );

            foreach ($detalles as &$detalle) {

                $idDetalle =
                    (int) (
                        $detalle['id']
                        ?? $detalle['id_detalle']
                        ?? 0
                    );

                $detalle['destinos'] = [];

                if ($idDetalle > 0) {

                    $detalle['destinos'] =
                        $this->model->listarDestinosPorDetalle(
                            $idDetalle
                        );
                }
            }

            unset($detalle);

            $materiales =
                $this->model->listarMaterialesActivos(
                    '',
                    100,
                    0
                );

            $fichas =
                $this->model->listarFichasDisponibles();

            $puedeGestionar = true;

            require ROOT_PATH .
                '/views/solicitudes/editar.php';
        }

        /**
         * =========================================================
         * ACTUALIZAR BORRADOR O SOLICITUD DEVUELTA
         * =========================================================
         */
        public function actualizarBorrador(): void
        {
            $this->exigirPermiso(
                'materiales.solicitudes.crear'
            );

            $this->validarPost();

            $idSolicitud =
                (int) (
                    $_POST['id_solicitud']
                    ?? $_POST['id']
                    ?? $_POST['solicitud_id']
                    ?? 0
                );

            if ($idSolicitud <= 0) {

                $this->flashError(
                    'Solicitud no válida.'
                );

                $this->redirect(
                    '/materiales/solicitudes'
                );
            }

            $solicitud =
                $this->model->obtenerSolicitud(
                    $idSolicitud
                );

            if (!$solicitud) {

                $this->flashError(
                    'La solicitud no existe.'
                );

                $this->redirect(
                    '/materiales/solicitudes'
                );
            }

            if (
                !in_array(
                    ($solicitud['estado'] ?? ''),
                    [
                        'borrador',
                        'devuelta',
                    ],
                    true
                )
            ) {

                $this->flashError(
                    'La solicitud ya no puede ser modificada.'
                );

                $this->redirect(
                    '/materiales/solicitudes/ver?id=' .
                    $idSolicitud
                );
            }

            $profesional =
                $this->profesionalActual();

            $idProfesionalActual =
                $profesional
                    ? (int) $profesional['id']
                    : 0;

            $esPropietario =
                $idProfesionalActual > 0
                &&
                (int) (
                    $solicitud[
                        'id_profesional_solicitante'
                    ] ?? 0
                ) === $idProfesionalActual;

            $esAdministrador =
                Auth::hasRole('Administrador');

            if (
                !$esPropietario
                &&
                !$esAdministrador
            ) {

                $this->flashError(
                    'No está autorizado para modificar esta solicitud.'
                );

                $this->redirect(
                    '/materiales/solicitudes'
                );
            }

            $tituloOriginal =
                trim(
                    (string) (
                        $solicitud['titulo']
                        ?? ''
                    )
                );

            $justificacionOriginal =
                trim(
                    (string) (
                        $solicitud['justificacion']
                        ?? ''
                    )
                );

            $materialesPost =
                $_POST['materiales']
                ?? [];

            if (
                !is_array($materialesPost)
                ||
                empty($materialesPost)
            ) {

                $this->flashError(
                    'Debe tener al menos un material en la solicitud.'
                );

                $this->redirect(
                    '/materiales/solicitudes/editar?id=' .
                    $idSolicitud
                );
            }

            $detallesExistentes = $this->model->listarDetalles($idSolicitud);
            $detallesExistentesPorMaterial = [];
            $destinosExistentesPorMaterial = [];
            foreach ($detallesExistentes as $detalleExistente) {
                $idExistente = (int) ($detalleExistente['id_material'] ?? 0);
                $idDetalleExistente = (int) ($detalleExistente['id'] ?? 0);
                if ($idExistente > 0) {
                    $detallesExistentesPorMaterial[$idExistente] = $detalleExistente;
                    if ($idDetalleExistente > 0) {
                        $destinosExistentesPorMaterial[$idExistente] =
                            $this->model->listarDestinosPorDetalle($idDetalleExistente);
                    }
                }
            }

            $detalles = [];

            foreach (
                $materialesPost as $materialPost
            ) {

                if (
                    !is_array($materialPost)
                ) {
                    continue;
                }

                $eliminar =
                    isset(
                        $materialPost['eliminar']
                    )
                    &&
                    (
                        $materialPost['eliminar'] === '1'
                        ||
                        $materialPost['eliminar'] === 'on'
                    );

                if ($eliminar) {
                    continue;
                }

                $idMaterial =
                    (int) (
                        $materialPost['id_material']
                        ?? 0
                    );

                $cantidad =
                    (float) (
                        $materialPost['cantidad']
                        ?? 0
                    );

                $observaciones =
                    trim(
                        (string) (
                            $materialPost['observaciones']
                            ?? ''
                        )
                    );
                $detalleExistente = $detallesExistentesPorMaterial[$idMaterial] ?? [];
                $unidadMedida = trim((string) (
                    $materialPost['unidad_medida']
                    ?? $detalleExistente['unidad_medida']
                    ?? 'Unidad'
                ));
                $descripcionTecnica = trim((string) (
                    $materialPost['descripcion_tecnica']
                    ?? $detalleExistente['descripcion_tecnica']
                    ?? ''
                ));

                $unidadesPermitidas = [
                    'Unidad', 'Metro', 'Metro Cuadrado', 'Metro Cúbico',
                    'Centímetro', 'Centímetro Cuadrado', 'Milímetro',
                    'Kilogramo', 'Gramo', 'Miligramo', 'Litro', 'Mililitro',
                    'Galón', 'Libra', 'Onza', 'Tonelada', 'Pulgada',
                    'Pie', 'Yarda', 'Otro',
                ];

                if (!in_array($unidadMedida, $unidadesPermitidas, true)) {
                    $this->flashError('Seleccione una unidad de medida válida para cada material.');
                    $this->redirect('/materiales/solicitudes/editar?id=' . $idSolicitud);
                }

                if ($descripcionTecnica === '') {
                    $this->flashError('La descripción técnica es obligatoria para cada material.');
                    $this->redirect('/materiales/solicitudes/editar?id=' . $idSolicitud);
                }

                if (
                    $idMaterial <= 0
                    ||
                    $cantidad <= 0
                ) {

                    $this->flashError(
                        'Todos los materiales deben tener una cantidad mayor que cero.'
                    );

                    $this->redirect(
                        '/materiales/solicitudes/editar?id=' .
                        $idSolicitud
                    );
                }

                $material =
                    $this->model->obtenerMaterialActivo(
                        $idMaterial
                    );

                if (!$material) {

                    $this->flashError(
                        'Uno de los materiales seleccionados ya no está activo.'
                    );

                    $this->redirect(
                        '/materiales/solicitudes/editar?id=' .
                        $idSolicitud
                    );
                }

                $destinosEnviados = array_key_exists('destinos', $materialPost);
                $destinosPost = $materialPost['destinos'] ?? [];

                if (!is_array($destinosPost)) {
                    $destinosPost = [];
                }

                // Esta pantalla no edita destinos. Si el formulario no envía
                // ese campo, se conservan los destinos previamente registrados.
                if (!$destinosEnviados && isset($destinosExistentesPorMaterial[$idMaterial])) {
                    foreach ($destinosExistentesPorMaterial[$idMaterial] as $destinoExistente) {
                        $destinosPost[] = [
                            'tipo_destino' => (string) ($destinoExistente['tipo_destino'] ?? ''),
                            'id_ficha' => (int) ($destinoExistente['id_ficha'] ?? 0),
                            'cantidad_destinada' => (float) ($destinoExistente['cantidad_destinada'] ?? 0),
                            'observaciones' => (string) ($destinoExistente['observaciones'] ?? ''),
                        ];
                    }
                }

                $destinos = [];

                $totalDestinado = 0.0;

                foreach (
                    $destinosPost as $destinoPost
                ) {

                    if (
                        !is_array($destinoPost)
                    ) {
                        continue;
                    }

                    $cantidadDestino =
                        (float) (
                            $destinoPost[
                                'cantidad_destinada'
                            ]
                            ?? 0
                        );

                    if (
                        $cantidadDestino <= 0
                    ) {
                        continue;
                    }

                    $tipoDestino =
                        trim(
                            (string) (
                                $destinoPost[
                                    'tipo_destino'
                                ]
                                ?? ''
                            )
                        );

                    if (
                        !in_array(
                            $tipoDestino,
                            [
                                'ficha',
                                'general_area',
                            ],
                            true
                        )
                    ) {

                        $this->flashError(
                            'Existe un destino con tipo no válido.'
                        );

                        $this->redirect(
                            '/materiales/solicitudes/editar?id=' .
                            $idSolicitud
                        );
                    }

                    $idFicha = null;

                    if (
                        $tipoDestino === 'ficha'
                    ) {

                        $idFicha =
                            (int) (
                                $destinoPost[
                                    'id_ficha'
                                ]
                                ?? 0
                            );

                        if (
                            $idFicha <= 0
                        ) {

                            $this->flashError(
                                'Debe seleccionar una ficha para cada destino por ficha.'
                            );

                            $this->redirect(
                                '/materiales/solicitudes/editar?id=' .
                                $idSolicitud
                            );
                        }
                    }

                    $totalDestinado +=
                        $cantidadDestino;

                    if (
                        $totalDestinado >
                        $cantidad
                    ) {

                        $this->flashError(
                            'La cantidad destinada no puede superar la cantidad solicitada para un material.'
                        );

                        $this->redirect(
                            '/materiales/solicitudes/editar?id=' .
                            $idSolicitud
                        );
                    }

                    $destinos[] = [
                        'tipo_destino' =>
                            $tipoDestino,

                        'id_ficha' =>
                            $idFicha,

                        'cantidad_destinada' =>
                            $cantidadDestino,

                        'observaciones' =>
                            trim(
                                (string) (
                                    $destinoPost[
                                        'observaciones'
                                    ]
                                    ?? ''
                                )
                            ),
                    ];
                }

                $detalles[] = [
                    'id_material' => $idMaterial,
                    'cantidad' => $cantidad,
                    'observaciones' => $observaciones,
                    'unidad_medida' => $unidadMedida,
                    'descripcion_tecnica' => $descripcionTecnica,
                    'es_consumo' => array_key_exists('es_consumo', $materialPost) ? (!empty($materialPost['es_consumo']) ? 1 : 0) : (!empty($detalleExistente['es_consumo']) ? 1 : 0),
                    'es_devolutivo' => array_key_exists('es_devolutivo', $materialPost) ? (!empty($materialPost['es_devolutivo']) ? 1 : 0) : (!empty($detalleExistente['es_devolutivo']) ? 1 : 0),
                    'es_software' => array_key_exists('es_software', $materialPost) ? (!empty($materialPost['es_software']) ? 1 : 0) : (!empty($detalleExistente['es_software']) ? 1 : 0),
                    'es_epp' => array_key_exists('es_epp', $materialPost) ? (!empty($materialPost['es_epp']) ? 1 : 0) : (!empty($detalleExistente['es_epp']) ? 1 : 0),
                    'destinos' => $destinos,
                ];
            }

            if (empty($detalles)) {

                $this->flashError(
                    'La solicitud debe conservar al menos un material.'
                );

                $this->redirect(
                    '/materiales/solicitudes/editar?id=' .
                    $idSolicitud
                );
            }

            $resultado =
                $this->model->actualizarBorradorCompleto(
                    $idSolicitud,
                    $tituloOriginal,
                    $justificacionOriginal !== ''
                        ? $justificacionOriginal
                        : null,
                    $detalles
                );

            if (!$resultado) {

                $this->flashError(
                    'No fue posible actualizar el borrador. Verifique la información e inténtelo nuevamente.'
                );

                $this->redirect(
                    '/materiales/solicitudes/editar?id=' .
                    $idSolicitud
                );
            }

            /*
             * Si la solicitud estaba devuelta, conservamos
             * el estado devuelta hasta que el solicitante
             * decida enviarla nuevamente.
             */
            $this->flashSuccess(
                'Los materiales de la solicitud fueron actualizados correctamente.'
            );

            $this->redirect(
                '/materiales/solicitudes/ver?id=' .
                $idSolicitud
            );
        }

        /**
         * =========================================================
         * ELIMINAR BORRADOR
         * =========================================================
         */
        public function eliminarBorrador(): void
        {
            $this->exigirPermiso(
                'materiales.solicitudes.crear'
            );

            $this->validarPost();

            $idSolicitud =
                (int) (
                    $_POST['id_solicitud']
                    ?? $_POST['id']
                    ?? $_POST['solicitud_id']
                    ?? $_POST['idSolicitud']
                    ?? $_GET['id_solicitud']
                    ?? $_GET['id']
                    ?? 0
                );

            if ($idSolicitud <= 0) {

                $this->flashError(
                    'Solicitud no válida.'
                );

                $this->redirect(
                    '/materiales/solicitudes'
                );
            }

            $solicitud =
                $this->model->obtenerSolicitud(
                    $idSolicitud
                );

            if (!$solicitud) {

                $this->flashError(
                    'La solicitud no existe.'
                );

                $this->redirect(
                    '/materiales/solicitudes'
                );
            }

            if (
                ($solicitud['estado'] ?? '')
                !== 'borrador'
            ) {

                $this->flashError(
                    'Solo se pueden eliminar solicitudes en estado borrador.'
                );

                $this->redirect(
                    '/materiales/solicitudes/ver?id=' .
                    $idSolicitud
                );
            }

            $profesional =
                $this->profesionalActual();

            $idProfesionalActual =
                $profesional
                    ? (int) (
                        $profesional['id']
                        ?? 0
                    )
                    : 0;

            $idProfesionalSolicitante =
                (int) (
                    $solicitud[
                        'id_profesional_solicitante'
                    ]
                    ??
                    $solicitud[
                        'id_profesional'
                    ]
                    ??
                    0
                );

            $esPropietario =
                $idProfesionalActual > 0
                &&
                $idProfesionalSolicitante ===
                    $idProfesionalActual;

            $esAdministrador =
                Auth::hasRole('Administrador');

            if (
                !$esPropietario
                &&
                !$esAdministrador
            ) {

                $this->flashError(
                    'No está autorizado para eliminar esta solicitud.'
                );

                $this->redirect(
                    '/materiales/solicitudes'
                );
            }

            $resultado =
                $this->model->eliminarBorrador(
                    $idSolicitud
                );

            if (!$resultado) {

                $this->flashError(
                    'No fue posible eliminar el borrador.'
                );

                $this->redirect(
                    '/materiales/solicitudes/ver?id=' .
                    $idSolicitud
                );
            }

            $this->flashSuccess(
                'La solicitud fue eliminada correctamente.'
            );

            $this->redirect(
                '/materiales/solicitudes'
            );
        }

        /**
         * =========================================================
         * BANDEJA DE SOLICITUDES PENDIENTES DE AVAL
         * =========================================================
         */
        public function aval(): void
        {
            $this->exigirPermiso(
                'materiales.solicitudes.gestionar'
            );

            $esAdministrador =
                Auth::hasRole('Administrador');

            $idProfesional = 0;

            /*
             * El Administrador puede consultar todas las
             * solicitudes pendientes y no necesita tener
             * un profesional activo asociado.
             *
             * El Coordinador solamente puede consultar las
             * solicitudes pertenecientes a procesos donde él
             * está configurado como coordinador.
             */
            if (!$esAdministrador) {

                $profesional =
                    $this->profesionalActual();

                $idProfesional =
                    $profesional
                        ? (int) $profesional['id']
                        : 0;

                if ($idProfesional <= 0) {
                    $this->error(
                        'El usuario actual no tiene un profesional activo asociado.'
                    );
                }
            }

            $solicitudes =
                $this->model->listarPendientesAval(
                    $esAdministrador
                        ? null
                        : $idProfesional
                );

            $tituloPagina =
                'Aval de solicitudes';

            require ROOT_PATH .
                '/views/solicitudes/aval.php';
        }

        /**
         * =========================================================
         * AVALAR SOLICITUD
         * =========================================================
         */
        public function avalar(): void
        {
            $this->exigirPermiso(
                'materiales.solicitudes.gestionar'
            );

            $this->validarPost();

            $idSolicitud =
                (int) (
                    $_POST['id_solicitud']
                    ?? $_POST['id']
                    ?? 0
                );

            $observacion =
                trim(
                    (string) (
                        $_POST['observacion']
                        ?? ''
                    )
                );

            if ($idSolicitud <= 0) {

                $this->flashError(
                    'Solicitud no válida.'
                );

                $this->redirect(
                    '/materiales/solicitudes/aval'
                );
            }

            $profesional =
                $this->profesionalActual();

            $idProfesional =
                $profesional
                    ? (int) $profesional['id']
                    : 0;

            $esAdministrador =
                Auth::hasRole('Administrador');

            if (
                !$esAdministrador
                &&
                $idProfesional <= 0
            ) {
                $this->error(
                    'El usuario actual no tiene un profesional activo asociado.'
                );
            }

            if (
                !$esAdministrador
                &&
                !$this->model->coordinadorPuedeRevisarSolicitud(
                    $idSolicitud,
                    $idProfesional
                )
            ) {

                $this->flashError(
                    'No está autorizado para avalar esta solicitud.'
                );

                $this->redirect(
                    '/materiales/solicitudes/aval'
                );
            }

            $idUsuario =
                $this->obtenerUsuarioActualId();

            $resultado =
                $this->model->registrarDecisionAval(
                    $idSolicitud,
                    'avalada',
                    $idUsuario,
                    $observacion !== ''
                        ? $observacion
                        : null
                );

            if (!$resultado) {

                $this->flashError(
                    'No fue posible avalar la solicitud. Es posible que ya haya sido revisada.'
                );

                $this->redirect(
                    '/materiales/solicitudes/aval'
                );
            }

            $this->flashSuccess(
                'La solicitud fue avalada correctamente.'
            );

            $this->redirect(
                '/materiales/solicitudes/aval'
            );
        }

        /**
         * =========================================================
         * DEVOLVER SOLICITUD
         * =========================================================
         */
        public function devolver(): void
        {
            $this->exigirPermiso(
                'materiales.solicitudes.gestionar'
            );

            $this->validarPost();

            $idSolicitud =
                (int) (
                    $_POST['id_solicitud']
                    ?? $_POST['id']
                    ?? 0
                );

            $observacion =
                trim(
                    (string) (
                        $_POST['observacion']
                        ?? ''
                    )
                );

            if ($idSolicitud <= 0) {

                $this->flashError(
                    'Solicitud no válida.'
                );

                $this->redirect(
                    '/materiales/solicitudes/aval'
                );
            }

            if ($observacion === '') {

                $this->flashError(
                    'Debe indicar la observación o motivo de la devolución.'
                );

                $this->redirect(
                    '/materiales/solicitudes/aval'
                );
            }

            $profesional =
                $this->profesionalActual();

            $idProfesional =
                $profesional
                    ? (int) $profesional['id']
                    : 0;

            $esAdministrador =
                Auth::hasRole('Administrador');

            if (
                !$esAdministrador
                &&
                $idProfesional <= 0
            ) {
                $this->error(
                    'El usuario actual no tiene un profesional activo asociado.'
                );
            }

            if (
                !$esAdministrador
                &&
                !$this->model->coordinadorPuedeRevisarSolicitud(
                    $idSolicitud,
                    $idProfesional
                )
            ) {

                $this->flashError(
                    'No está autorizado para devolver esta solicitud.'
                );

                $this->redirect(
                    '/materiales/solicitudes/aval'
                );
            }

            $idUsuario =
                $this->obtenerUsuarioActualId();

            $resultado =
                $this->model->registrarDecisionAval(
                    $idSolicitud,
                    'devuelta',
                    $idUsuario,
                    $observacion
                );

            if (!$resultado) {

                $this->flashError(
                    'No fue posible devolver la solicitud. Es posible que ya haya sido revisada.'
                );

                $this->redirect(
                    '/materiales/solicitudes/aval'
                );
            }

            $this->flashSuccess(
                'La solicitud fue devuelta al solicitante para su corrección.'
            );

            $this->redirect(
                '/materiales/solicitudes/aval'
            );
        }

        /**
         * =========================================================
         * OBTENER PROFESIONAL ACTUAL
         * =========================================================
         */
        private function profesionalActual(): ?array
        {
            $idUsuario =
                $this->obtenerUsuarioActualId();

            if ($idUsuario <= 0) {
                return null;
            }

            return $this->model->obtenerProfesionalPorUsuario(
                $idUsuario
            );
        }

        /**
         * =========================================================
         * EXIGIR PROFESIONAL
         * =========================================================
         */
        private function exigirProfesional(): array
        {
            $profesional =
                $this->profesionalActual();

            if (!$profesional) {

                $this->error(
                    'El usuario actual no tiene un profesional activo asociado.'
                );
            }

            return $profesional;
        }

        /**
         * =========================================================
         * EXIGIR PERMISO
         * =========================================================
         */
        private function exigirPermiso(
            string $permiso
        ): void {
            if (!Auth::can($permiso)) {

                $this->error(
                    'No tiene permisos para realizar esta acción.'
                );
            }
        }

        /**
         * =========================================================
         * OBTENER USUARIO ACTUAL
         * =========================================================
         */
        private function obtenerUsuarioActualId(): int
        {
            if (
                isset(
                    $_SESSION['usuario_id']
                )
            ) {
                return (int) $_SESSION[
                    'usuario_id'
                ];
            }

            if (
                isset(
                    $_SESSION['id_usuario']
                )
            ) {
                return (int) $_SESSION[
                    'id_usuario'
                ];
            }

            if (
                isset(
                    $_SESSION['usuario']
                )
                &&
                is_array(
                    $_SESSION['usuario']
                )
                &&
                isset(
                    $_SESSION['usuario']['id']
                )
            ) {
                return (int) $_SESSION[
                    'usuario'
                ]['id'];
            }

            return 0;
        }

        /**
         * =========================================================
         * OBTENER CARRITO
         * =========================================================
         */
        private function obtenerCarrito(): array
        {
            if (
                !isset(
                    $_SESSION[
                        $this->sessionCartKey
                    ]
                )
                ||
                !is_array(
                    $_SESSION[
                        $this->sessionCartKey
                    ]
                )
            ) {
                $_SESSION[
                    $this->sessionCartKey
                ] = [];
            }

            return $_SESSION[
                $this->sessionCartKey
            ];
        }

        /**
         * =========================================================
         * GUARDAR CARRITO
         * =========================================================
         */
        private function guardarCarrito(
            array $carrito
        ): void {
            $_SESSION[
                $this->sessionCartKey
            ] = $carrito;
        }

        /**
         * =========================================================
         * OBTENER FORMULARIO TEMPORAL
         * =========================================================
         */
        private function obtenerFormularioTemporal(): array
        {
            if (
                !isset(
                    $_SESSION[
                        $this->sessionFormKey
                    ]
                )
                ||
                !is_array(
                    $_SESSION[
                        $this->sessionFormKey
                    ]
                )
            ) {
                $_SESSION[
                    $this->sessionFormKey
                ] = [
                    'id_proceso' =>
                        0,

                    'id_proceso_area' =>
                        0,

                    'titulo' =>
                        '',

                    'justificacion' =>
                        '',
                ];
            }

            return [
                'id_proceso' =>
                    (int) (
                        $_SESSION[
                            $this->sessionFormKey
                        ]['id_proceso']
                        ?? 0
                    ),

                'id_proceso_area' =>
                    (int) (
                        $_SESSION[
                            $this->sessionFormKey
                        ]['id_proceso_area']
                        ?? 0
                    ),

                'titulo' =>
                    (string) (
                        $_SESSION[
                            $this->sessionFormKey
                        ]['titulo']
                        ?? ''
                    ),

                'justificacion' =>
                    (string) (
                        $_SESSION[
                            $this->sessionFormKey
                        ]['justificacion']
                        ?? ''
                    ),
            ];
        }

        /**
         * =========================================================
         * GUARDAR FORMULARIO TEMPORAL
         * =========================================================
         */
        private function guardarFormularioTemporal(
            array $formulario
        ): void {
            $_SESSION[
                $this->sessionFormKey
            ] = [
                'id_proceso' =>
                    (int) (
                        $formulario['id_proceso']
                        ?? 0
                    ),

                'id_proceso_area' =>
                    (int) (
                        $formulario['id_proceso_area']
                        ?? 0
                    ),

                'titulo' =>
                    trim(
                        (string) (
                            $formulario['titulo']
                            ?? ''
                        )
                    ),

                'justificacion' =>
                    trim(
                        (string) (
                            $formulario['justificacion']
                            ?? ''
                        )
                    ),
            ];
        }

        /**
         * =========================================================
         * ACTUALIZAR FORMULARIO DESDE POST
         * =========================================================
         */
        private function actualizarFormularioDesdePost(): void
        {
            $formulario =
                $this->obtenerFormularioTemporal();

            if (isset($_POST['id_proceso'])) {

                $formulario['id_proceso'] =
                    (int) $_POST['id_proceso'];
            }

            if (isset($_POST['id_proceso_area'])) {

                $formulario['id_proceso_area'] =
                    (int) $_POST['id_proceso_area'];
            }

            if (isset($_POST['titulo'])) {

                $formulario['titulo'] =
                    trim(
                        (string) $_POST['titulo']
                    );
            }

            if (isset($_POST['justificacion'])) {

                $formulario['justificacion'] =
                    trim(
                        (string) $_POST['justificacion']
                    );
            }

            $this->guardarFormularioTemporal(
                $formulario
            );
        }

        /**
         * =========================================================
         * LIMPIAR FORMULARIO TEMPORAL
         * =========================================================
         */
        private function limpiarFormularioTemporal(): void
        {
            $_SESSION[
                $this->sessionFormKey
            ] = [
                'id_proceso' =>
                    0,

                'id_proceso_area' =>
                    0,

                'titulo' =>
                    '',

                'justificacion' =>
                    '',
            ];
        }

        /**
         * =========================================================
         * VALIDAR POST
         * =========================================================
         */
        private function validarPost(): void
        {
            if (
                ($_SERVER['REQUEST_METHOD'] ?? '')
                !== 'POST'
            ) {
                $this->error(
                    'Método de solicitud no permitido.'
                );
            }

            exigirCsrf();
        }

        /**
         * =========================================================
         * FLASH SUCCESS
         * =========================================================
         */
        private function flashSuccess(
            string $mensaje
        ): void {
            $_SESSION['flash']['success'] =
                $mensaje;
        }

        /**
         * =========================================================
         * FLASH ERROR
         * =========================================================
         */
        private function flashError(
            string $mensaje
        ): void {
            $_SESSION['flash']['error'] =
                $mensaje;
        }

        /**
         * =========================================================
         * REDIRECCIÓN A CREAR
         * =========================================================
         */
        private function redirectCrear(
            string $buscar = '',
            int $pagina = 1
        ): void {

            $formulario =
                $this->obtenerFormularioTemporal();

            $parametros = [];

            if (
                (int) (
                    $formulario['id_proceso']
                    ?? 0
                ) > 0
            ) {
                $parametros['id_proceso'] =
                    (int) $formulario[
                        'id_proceso'
                    ];
            }

            if (
                (int) (
                    $formulario['id_proceso_area']
                    ?? 0
                ) > 0
            ) {
                $parametros['id_proceso_area'] =
                    (int) $formulario[
                        'id_proceso_area'
                    ];
            }

            if (
                trim($buscar) !== ''
            ) {
                $parametros['buscar'] =
                    trim($buscar);
            }

            if ($pagina > 1) {

                $parametros['pagina'] =
                    $pagina;
            }

            if (
                trim(
                    (string) (
                        $formulario['titulo']
                        ?? ''
                    )
                ) !== ''
            ) {
                $parametros['titulo'] =
                    (string) $formulario[
                        'titulo'
                    ];
            }

            if (
                trim(
                    (string) (
                        $formulario['justificacion']
                        ?? ''
                    )
                ) !== ''
            ) {
                $parametros['justificacion'] =
                    (string) $formulario[
                        'justificacion'
                    ];
            }

            $url =
                '/materiales/solicitudes/crear';

            if (!empty($parametros)) {

                $url .= '?' .
                    http_build_query(
                        $parametros
                    );
            }

            $this->redirect(
                $url
            );
        }

        /**
         * =========================================================
         * REDIRECT
         * =========================================================
         */
        private function redirect(
            string $ruta
        ): void {
            header(
                'Location: ' .
                url($ruta)
            );

            exit;
        }

        /**
         * =========================================================
         * ERROR
         * =========================================================
         */
        private function error(
            string $mensaje
        ): void {
            http_response_code(403);

            echo '<!DOCTYPE html>';
            echo '<html lang="es">';
            echo '<head>';
            echo '<meta charset="UTF-8">';
            echo '<title>Error</title>';
            echo '</head>';
            echo '<body style="font-family:Arial,sans-serif;padding:40px;">';
            echo '<h2>Error</h2>';
            echo '<p>' .
                e($mensaje) .
                '</p>';
            echo '</body>';
            echo '</html>';

            exit;
        }
    }
}