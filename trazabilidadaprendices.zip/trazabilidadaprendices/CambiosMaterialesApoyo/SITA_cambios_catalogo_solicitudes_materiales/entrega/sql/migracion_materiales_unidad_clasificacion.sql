-- SITA: migración del catálogo y detalle de solicitudes de materiales.
-- Hacer una copia de seguridad antes de ejecutar.
-- Ejecutar una sola vez sobre la base de datos de SITA.

START TRANSACTION;

-- La unidad deja de pertenecer al catálogo. La selección se guarda por solicitud.
ALTER TABLE materiales_catalogo
    DROP COLUMN unidad_medida;

-- Los detalles históricos quedan con unidad "Unidad" y campos de clasificación apagados.
-- descripcion_tecnica queda vacía en solicitudes antiguas; las nuevas se validan desde PHP.
ALTER TABLE materiales_solicitud_detalle
    ADD COLUMN unidad_medida VARCHAR(50) NOT NULL DEFAULT 'Unidad' AFTER observaciones,
    ADD COLUMN descripcion_tecnica VARCHAR(2000) NOT NULL DEFAULT '' AFTER unidad_medida,
    ADD COLUMN es_consumo TINYINT(1) UNSIGNED NOT NULL DEFAULT 0 AFTER descripcion_tecnica,
    ADD COLUMN es_devolutivo TINYINT(1) UNSIGNED NOT NULL DEFAULT 0 AFTER es_consumo,
    ADD COLUMN es_software TINYINT(1) UNSIGNED NOT NULL DEFAULT 0 AFTER es_devolutivo,
    ADD COLUMN es_epp TINYINT(1) UNSIGNED NOT NULL DEFAULT 0 AFTER es_software;

COMMIT;
