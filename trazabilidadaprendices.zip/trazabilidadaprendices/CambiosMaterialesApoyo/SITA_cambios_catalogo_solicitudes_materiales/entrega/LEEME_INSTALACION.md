# SITA — Cambios del catálogo y solicitudes de materiales

## Alcance incluido

- El catálogo se mantiene alimentado mediante importación Excel; no se permite crear ni editar materiales individualmente desde las acciones antiguas del controlador.
- El Excel de catálogo debe tener las columnas **Código UNSPSC** y **Nombre Producto**. La importación no usa una columna de unidad de medida.
- La unidad de medida, descripción técnica, cantidad, observaciones y las clasificaciones Consumo, Devolutivo, Software y EPP se registran en cada detalle de una solicitud.
- Las cuatro clasificaciones son independientes; se pueden seleccionar varias o ninguna.
- La vista de consulta muestra estos datos y conserva la visualización de destinos registrados por ficha o área.
- El historial de importaciones conserva su columna histórica `materiales_importacion_detalle.unidad_medida`; las nuevas filas de historial pueden quedar con `NULL`.

## Archivos incluidos y destino

Copie cada archivo a la ruta equivalente de su proyecto SITA, conservando los nombres:

| Archivo del paquete | Ruta en el proyecto |
|---|---|
| `controllers/MaterialesController.php` | `controllers/MaterialesController.php` |
| `controllers/MaterialesImportacionController.php` | `controllers/MaterialesImportacionController.php` |
| `controllers/MaterialesSolicitudController.php` | `controllers/MaterialesSolicitudController.php` |
| `models/MaterialesModel.php` | `models/MaterialesModel.php` |
| `models/MaterialesImportacionModel.php` | `models/MaterialesImportacionModel.php` |
| `models/MaterialesSolicitudModel.php` | `models/MaterialesSolicitudModel.php` |
| `views/materiales/index.php` | `views/materiales/index.php` |
| `views/materiales/importacion.php` | `views/materiales/importacion.php` |
| `views/materiales/importacion_preview.php` | `views/materiales/importacion_preview.php` |
| `views/solicitudes/crear.php` | `views/solicitudes/crear.php` |
| `views/solicitudes/carrito.php` | `views/solicitudes/carrito.php` |
| `views/solicitudes/editar.php` | `views/solicitudes/editar.php` |
| `views/solicitudes/ver.php` | `views/solicitudes/ver.php` |

## Antes de instalar

1. Haga una copia de seguridad completa de la base de datos.
2. Haga una copia de los 13 archivos actuales que serán reemplazados.
3. Revise que los archivos del proyecto usen las mismas tablas y nombres indicados en la migración.
4. No ejecute la migración más de una vez. El SQL no es idempotente: si las columnas ya existen o `materiales_catalogo.unidad_medida` ya fue eliminada, la ejecución fallará.

## Orden recomendado

1. En una copia de pruebas, ejecute `sql/migracion_materiales_unidad_clasificacion.sql` sobre la base de datos SITA después del respaldo.
2. Reemplace los archivos PHP por las rutas de la tabla.
3. Pruebe la importación con un Excel pequeño que contenga los encabezados `Código UNSPSC` y `Nombre Producto` antes de importar las aproximadamente 49.000 filas.
4. Verifique que la vista previa y el historial de importación funcionen, y luego pruebe la aplicación de la importación.
5. Cree una solicitud de prueba con descripción técnica, unidad, varias clasificaciones, cantidad y observaciones. Guárdela como borrador, vuelva a abrirla, edítela y consulte el resultado.
6. Verifique también que los destinos por ficha/área se conserven al editar una solicitud existente.
7. Solo después de validar en pruebas, aplique el cambio en producción.

## Cambios de base de datos

La migración elimina `materiales_catalogo.unidad_medida` y agrega a `materiales_solicitud_detalle`:

- `unidad_medida`
- `descripcion_tecnica`
- `es_consumo`
- `es_devolutivo`
- `es_software`
- `es_epp`

Los registros antiguos reciben la unidad predeterminada `Unidad`, las clasificaciones en `0` y la descripción técnica vacía. Las nuevas solicitudes exigen descripción técnica y unidad válidas desde PHP.

**Importante:** no he ejecutado este SQL en su equipo ni he modificado su instalación local. El paquete contiene archivos preparados para que usted los revise y aplique en una copia de pruebas primero.
