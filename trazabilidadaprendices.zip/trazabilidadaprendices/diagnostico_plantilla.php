<?php
declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '1');

echo '<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8">';
echo '<title>Diagnóstico plantilla GFPI-F-186</title>';
echo '<style>
body{font-family:Arial,sans-serif;margin:25px}
table{border-collapse:collapse;width:100%}
th,td{border:1px solid #ccc;padding:7px;text-align:left;vertical-align:top}
th{background:#eee}
pre{white-space:pre-wrap;word-break:break-word}
</style></head><body>';

echo '<h2>Diagnóstico de plantilla GFPI-F-186</h2>';

$autoload = __DIR__ . '/vendor/autoload.php';
$plantilla = __DIR__ . '/Copia de GFPI-F-186 Formato Lista Maestra Archivo 2026.xlsx';

if (!is_file($autoload)) {
    exit('<p>Error: no se encontró vendor/autoload.php.</p>');
}

require_once $autoload;

if (!class_exists(\PhpOffice\PhpSpreadsheet\IOFactory::class)) {
    exit('<p>Error: PhpSpreadsheet no está disponible.</p>');
}

if (!is_file($plantilla)) {
    exit(
        '<p>Error: no se encontró la plantilla en:</p><pre>'
        . htmlspecialchars($plantilla, ENT_QUOTES, 'UTF-8')
        . '</pre>'
    );
}

try {
    $libro = \PhpOffice\PhpSpreadsheet\IOFactory::load($plantilla);
    $hoja = $libro->getActiveSheet();

    echo '<p>Hoja analizada: '
        . htmlspecialchars($hoja->getTitle(), ENT_QUOTES, 'UTF-8')
        . '</p>';

    echo '<table><thead><tr>';
    echo '<th>Celda</th><th>Contenido</th>';
    echo '</tr></thead><tbody>';

    $ultimaFila = min($hoja->getHighestRow(), 80);
    $ultimaColumna = min(
        \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString(
            $hoja->getHighestColumn()
        ),
        20
    );

    for ($fila = 1; $fila <= $ultimaFila; $fila++) {
        for ($columna = 1; $columna <= $ultimaColumna; $columna++) {
            $celda = $hoja->getCell([$columna, $fila]);
            $valor = $celda->getFormattedValue();

            if ($valor === null || trim((string)$valor) === '') {
                continue;
            }

            $coordenada = $celda->getCoordinate();

            echo '<tr><td><strong>'
                . htmlspecialchars($coordenada, ENT_QUOTES, 'UTF-8')
                . '</strong></td><td>'
                . nl2br(htmlspecialchars(
                    (string)$valor,
                    ENT_QUOTES,
                    'UTF-8'
                ))
                . '</td></tr>';
        }
    }

    echo '</tbody></table>';

    echo '<p>Fin del diagnóstico. No se modificó la plantilla.</p>';

    $libro->disconnectWorksheets();
    unset($libro);

} catch (\Throwable $e) {
    echo '<p>Error al leer la plantilla:</p><pre>'
        . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8')
        . '</pre>';
}

echo '</body></html>';
